# API Documentation

## Web API Reference

The Cobalt Price Tracker provides a RESTful API built with FastAPI. All endpoints return JSON data unless otherwise specified.

### Base URL

```
http://localhost:8000
```

### Authentication

Currently, no authentication is required. In production, consider implementing API key authentication.

## Endpoints

### Root

#### GET /

Returns basic API information and available endpoints.

**Response:**
```json
{
  "name": "Cobalt Price Tracker API",
  "version": "0.1.0",
  "description": "Monitor and analyze cobalt prices from multiple sources",
  "endpoints": {
    "current_prices": "/prices/current",
    "historical_prices": "/prices/history",
    "statistics": "/prices/stats",
    "update": "/prices/update",
    "charts": "/charts/{chart_type}",
    "reports": "/reports/{format}",
    "alerts": "/alerts"
  }
}
```

### Price Data

#### GET /prices/current

Fetch current cobalt prices from all available sources.

**Response:**
```json
[
  {
    "id": null,
    "price": 15.75,
    "currency": "USD",
    "unit": "lb",
    "source": "MetalPriceAPI",
    "timestamp": "2024-09-17T10:30:00"
  }
]
```

#### GET /prices/history

Get historical price data.

**Parameters:**
- `days` (optional): Number of days of historical data (default: 30)
- `source` (optional): Filter by specific data source

**Example:**
```
GET /prices/history?days=7&source=MetalPriceAPI
```

**Response:**
```json
[
  {
    "id": 1,
    "price": 15.25,
    "currency": "USD",
    "unit": "lb",
    "source": "MetalPriceAPI",
    "timestamp": "2024-09-10T10:00:00"
  },
  {
    "id": 2,
    "price": 15.50,
    "currency": "USD",
    "unit": "lb",
    "source": "MetalPriceAPI",
    "timestamp": "2024-09-11T10:00:00"
  }
]
```

#### GET /prices/latest

Get the most recent price data.

**Parameters:**
- `source` (optional): Filter by specific data source

**Response:**
```json
{
  "id": 100,
  "price": 15.75,
  "currency": "USD",
  "unit": "lb",
  "source": "MetalPriceAPI",
  "timestamp": "2024-09-17T10:30:00"
}
```

#### GET /prices/stats

Get price statistics and analysis.

**Parameters:**
- `days` (optional): Number of days to analyze (default: 30)

**Response:**
```json
{
  "count": 30,
  "min": 14.50,
  "max": 16.25,
  "avg": 15.42,
  "latest": 15.75,
  "change_24h": 2.3,
  "change_7d": -1.2,
  "change_30d": 5.8
}
```

#### POST /prices/update

Update price data from all sources.

**Response:**
```json
{
  "success": true,
  "prices_fetched": 3,
  "duration_seconds": 2.45,
  "timestamp": "2024-09-17T10:30:00",
  "sources": ["MetalPriceAPI", "WebScraper", "MockSource"],
  "error": null
}
```

### Charts

#### GET /charts/{chart_type}

Generate and return price charts.

**Path Parameters:**
- `chart_type`: Type of chart (`timeline`, `comparison`, `statistics`, `dashboard`)

**Query Parameters:**
- `days` (optional): Number of days of data to include (default: 30)
- `format` (optional): Image format (default: png)

**Example:**
```
GET /charts/dashboard?days=30&format=png
```

**Response:** PNG image file

### Reports

#### GET /reports/{report_format}

Generate and return analysis reports.

**Path Parameters:**
- `report_format`: Report format (`json`, `html`, `csv`)

**Query Parameters:**
- `days` (optional): Number of days to include (default: 30)

**Examples:**

```
GET /reports/json?days=30
```

**JSON Response:**
```json
{
  "report_generated": "2024-09-17T10:30:00",
  "period_days": 30,
  "data_points": 150,
  "date_range": {
    "start": "2024-08-18T10:00:00",
    "end": "2024-09-17T10:30:00"
  },
  "price_statistics": {
    "current": 15.75,
    "average": 15.42,
    "median": 15.40,
    "min": 14.50,
    "max": 16.25,
    "std_dev": 0.45,
    "volatility": 2.92
  },
  "price_changes": {
    "1d": {
      "absolute": 0.35,
      "percent": 2.3,
      "direction": "up"
    },
    "7d": {
      "absolute": -0.18,
      "percent": -1.2,
      "direction": "down"
    }
  },
  "source_analysis": {
    "MetalPriceAPI": {
      "data_points": 100,
      "average_price": 15.45,
      "price_range": {
        "min": 14.50,
        "max": 16.25
      },
      "last_update": "2024-09-17T10:30:00",
      "reliability_score": 95.5
    }
  },
  "trend_analysis": {
    "trend": "upward",
    "strength": 15.2,
    "moving_averages": {
      "short_term": 15.65,
      "long_term": 15.35
    }
  },
  "alerts": [
    {
      "type": "significant_change",
      "severity": "info",
      "message": "Significant price change: +2.3%",
      "value": 2.3
    }
  ]
}
```

```
GET /reports/html?days=30
```

**Response:** HTML file download

```
GET /reports/csv?days=30
```

**Response:** CSV file download

### Alerts

#### POST /alerts

Create a new price alert.

**Request Body:**
```json
{
  "alert_type": "above",
  "threshold": 20.0,
  "currency": "USD",
  "unit": "lb",
  "email": "user@example.com"
}
```

**Response:**
```json
{
  "id": 1,
  "alert_type": "above",
  "threshold": 20.0,
  "currency": "USD",
  "unit": "lb",
  "email": "user@example.com",
  "created_at": "2024-09-17T10:30:00"
}
```

#### GET /alerts

Get all active alerts.

**Response:**
```json
[
  {
    "id": 1,
    "alert_type": "above",
    "threshold": 20.0,
    "currency": "USD",
    "unit": "lb",
    "email": "user@example.com",
    "created_at": "2024-09-17T10:30:00",
    "last_triggered": null
  }
]
```

#### GET /alerts/check

Check for triggered alerts.

**Response:**
```json
{
  "triggered_count": 1,
  "alerts": [
    {
      "alert_id": 1,
      "alert_type": "above",
      "threshold": 20.0,
      "current_price": 20.5,
      "email": "user@example.com"
    }
  ]
}
```

#### DELETE /alerts/{alert_id}

Deactivate a specific alert.

**Response:**
```json
{
  "message": "Alert 1 deactivated successfully"
}
```

### System Information

#### GET /info

Get system information and statistics.

**Response:**
```json
{
  "system": {
    "version": "0.1.0",
    "update_interval": 60,
    "log_level": "INFO"
  },
  "database": {
    "total_prices": 1250,
    "total_alerts": 3,
    "active_alerts": 2,
    "sources": ["MetalPriceAPI", "WebScraper", "MockSource"],
    "oldest_record": "2024-08-01T10:00:00",
    "newest_record": "2024-09-17T10:30:00",
    "database_url": "sqlite:///cobalt_prices.db"
  },
  "api_keys": {
    "metal_price_api": true,
    "alpha_vantage": false
  }
}
```

## Error Responses

All error responses follow this format:

```json
{
  "detail": "Error message describing what went wrong"
}
```

### Common HTTP Status Codes

- `200`: Success
- `400`: Bad Request (invalid parameters)
- `404`: Not Found (resource doesn't exist)
- `500`: Internal Server Error

## Rate Limiting

Currently, no rate limiting is implemented. Consider implementing rate limiting for production use.

## Interactive Documentation

FastAPI automatically generates interactive API documentation:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## Python Client Example

```python
import requests

# Base URL
BASE_URL = "http://localhost:8000"

# Get current prices
response = requests.get(f"{BASE_URL}/prices/current")
prices = response.json()
print(f"Current prices: {prices}")

# Get statistics
response = requests.get(f"{BASE_URL}/prices/stats?days=7")
stats = response.json()
print(f"7-day statistics: {stats}")

# Create an alert
alert_data = {
    "alert_type": "above",
    "threshold": 20.0,
    "email": "your@email.com"
}
response = requests.post(f"{BASE_URL}/alerts", json=alert_data)
alert = response.json()
print(f"Created alert: {alert}")

# Generate a chart
response = requests.get(f"{BASE_URL}/charts/dashboard?days=30")
with open("cobalt_chart.png", "wb") as f:
    f.write(response.content)
print("Chart saved as cobalt_chart.png")
```

## WebSocket Support (Future)

Future versions may include WebSocket support for real-time price updates:

```javascript
// Example WebSocket client (future feature)
const ws = new WebSocket('ws://localhost:8000/ws/prices');
ws.onmessage = function(event) {
    const priceData = JSON.parse(event.data);
    console.log('New price:', priceData);
};
```