#!/usr/bin/env python3
"""
Basic usage example for the Cobalt Price Tracker.

This script demonstrates the main features of the cobalt price tracking system.
"""

import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

# Add the src directory to the Python path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from cobalt_price import CobaltPriceTracker, Config
from cobalt_price.visualization.charts import ChartGenerator
from cobalt_price.visualization.reports import ReportGenerator


def main():
    """Demonstrate basic usage of the Cobalt Price Tracker."""
    
    print("🔧 Cobalt Price Tracker - Basic Usage Example")
    print("=" * 50)
    
    # Initialize the tracker
    print("\n1. Initializing Cobalt Price Tracker...")
    tracker = CobaltPriceTracker()
    print(f"   ✓ Initialized with {len(tracker.data_sources)} data sources")
    
    # Fetch current prices
    print("\n2. Fetching current prices...")
    try:
        prices = tracker.fetch_current_prices()
        print(f"   ✓ Fetched {len(prices)} prices from available sources")
        
        for price in prices:
            print(f"   - {price.source}: ${price.price:.2f} {price.currency}/{price.unit}")
        
        # Store prices if we got any
        if prices:
            print("\n3. Storing prices in database...")
            tracker.store_prices(prices)
            print("   ✓ Prices stored successfully")
        else:
            print("   ⚠ No prices to store")
            
    except Exception as e:
        print(f"   ✗ Error fetching prices: {e}")
        prices = []
    
    # Get historical data
    print("\n4. Retrieving historical data...")
    try:
        historical_prices = tracker.get_historical_prices(days=30)
        print(f"   ✓ Found {len(historical_prices)} historical records")
        
        if historical_prices:
            latest = historical_prices[-1]
            oldest = historical_prices[0]
            print(f"   - Date range: {oldest.timestamp.date()} to {latest.timestamp.date()}")
            print(f"   - Latest price: ${latest.price:.2f}")
    except Exception as e:
        print(f"   ✗ Error retrieving historical data: {e}")
        historical_prices = []
    
    # Calculate statistics
    print("\n5. Calculating price statistics...")
    try:
        stats = tracker.get_price_statistics(days=30)
        
        if stats:
            print("   ✓ Price Statistics (30 days):")
            print(f"   - Count: {stats.get('count', 'N/A')}")
            print(f"   - Latest: ${stats.get('latest', 0):.2f}")
            print(f"   - Average: ${stats.get('avg', 0):.2f}")
            print(f"   - Range: ${stats.get('min', 0):.2f} - ${stats.get('max', 0):.2f}")
            
            if stats.get('change_24h') is not None:
                change = stats['change_24h']
                direction = "↑" if change > 0 else "↓" if change < 0 else "→"
                print(f"   - 24h Change: {direction} {change:+.2f}%")
        else:
            print("   ⚠ No statistics available (insufficient data)")
            
    except Exception as e:
        print(f"   ✗ Error calculating statistics: {e}")
        stats = {}
    
    # Generate visualizations (if we have data)
    if historical_prices and len(historical_prices) > 1:
        print("\n6. Generating visualizations...")
        try:
            chart_gen = ChartGenerator()
            
            # Create a simple timeline chart
            timeline_path = chart_gen.create_price_timeline(
                historical_prices[:50],  # Limit to 50 most recent points
                title="Cobalt Price Timeline (Recent Data)"
            )
            print(f"   ✓ Timeline chart saved: {timeline_path}")
            
            # Create a dashboard if we have enough data
            if len(historical_prices) > 10:
                dashboard_path = chart_gen.create_dashboard(
                    historical_prices[:100],  # Limit to 100 most recent points
                    title="Cobalt Price Dashboard"
                )
                print(f"   ✓ Dashboard saved: {dashboard_path}")
                
        except Exception as e:
            print(f"   ✗ Error generating visualizations: {e}")
    else:
        print("\n6. Skipping visualizations (insufficient data)")
    
    # Generate a report (if we have data)
    if historical_prices:
        print("\n7. Generating analysis report...")
        try:
            report_gen = ReportGenerator()
            
            # Generate JSON report
            report_data = report_gen.generate_summary_report(historical_prices, period_days=30)
            json_path = report_gen.save_report_json(report_data)
            print(f"   ✓ JSON report saved: {json_path}")
            
            # Generate HTML report if we have sufficient data
            if len(historical_prices) > 5:
                html_path = report_gen.generate_html_report(historical_prices, period_days=30)
                print(f"   ✓ HTML report saved: {html_path}")
                
        except Exception as e:
            print(f"   ✗ Error generating reports: {e}")
    else:
        print("\n7. Skipping report generation (no historical data)")
    
    # Demonstrate alert creation
    print("\n8. Creating a sample price alert...")
    try:
        # Create an alert for prices above $20
        alert = tracker.db_manager.create_alert(
            alert_type="above",
            threshold=20.0,
            email="example@email.com"
        )
        print(f"   ✓ Created alert: ID {alert.id}, trigger above ${alert.threshold:.2f}")
        
        # Check if any alerts are triggered
        triggered_alerts = tracker.check_alerts()
        if triggered_alerts:
            print(f"   ⚠ {len(triggered_alerts)} alert(s) currently triggered")
        else:
            print("   ✓ No alerts currently triggered")
            
    except Exception as e:
        print(f"   ✗ Error with alerts: {e}")
    
    # Show system information
    print("\n9. System Information:")
    try:
        db_stats = tracker.db_manager.get_database_stats()
        print(f"   - Total price records: {db_stats['total_prices']}")
        print(f"   - Active alerts: {db_stats['active_alerts']}")
        print(f"   - Data sources: {', '.join(db_stats['sources']) if db_stats['sources'] else 'None'}")
        print(f"   - Database: {db_stats['database_url']}")
    except Exception as e:
        print(f"   ✗ Error getting system info: {e}")
    
    print("\n" + "=" * 50)
    print("✅ Basic usage example completed!")
    print("\nNext steps:")
    print("1. Configure API keys in .env file for real data")
    print("2. Set up scheduled updates with cron or systemd")
    print("3. Start the web API: cobalt-price web")
    print("4. Explore the CLI: cobalt-price --help")
    print("5. Check the generated charts and reports in the data/ directory")


if __name__ == "__main__":
    main()