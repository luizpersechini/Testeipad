# Cobalt Price Tracker

A comprehensive Python application for tracking, analyzing, and visualizing cobalt prices from multiple data sources. This project provides real-time price monitoring, historical data analysis, price alerts, and detailed reporting capabilities.

## Features

### 🔍 **Multi-Source Data Collection**
- **Metal Price API Integration**: Real-time cobalt prices from metalpriceapi.com
- **Web Scraping**: Backup data collection from financial websites
- **Mock Data Source**: For testing and development purposes

### 📊 **Data Analysis & Visualization**
- Interactive charts and graphs (timeline, comparison, statistics, dashboard)
- Comprehensive price statistics and trend analysis
- Moving averages and volatility calculations
- Source correlation analysis

### 📈 **Reporting System**
- JSON, HTML, and CSV report formats
- Automated report generation
- Price change analysis and alerts
- Historical data export

### 🚨 **Alert System**
- Price threshold alerts (above/below specific values)
- Significant price change notifications
- Email notification support
- Customizable alert conditions

### 🌐 **Multiple Interfaces**
- **Command Line Interface (CLI)**: Full-featured terminal interface
- **Web API**: RESTful API with FastAPI
- **Python Library**: Direct integration into other projects

### 💾 **Data Storage**
- SQLite database for historical data
- Configurable retention policies
- Data integrity and backup support

## Quick Start

### Installation

1. **Clone the repository:**
```bash
git clone git@github.com:luizpersechini/Cobalt-Price.git
cd Cobalt-Price
```

2. **Install dependencies:**
```bash
pip install -r requirements.txt
```

3. **Configure environment variables:**
```bash
cp .env.example .env
# Edit .env with your API keys and configuration
```

4. **Install the package:**
```bash
pip install -e .
```

### Basic Usage

#### Command Line Interface

```bash
# Fetch current prices
cobalt-price fetch --save

# View historical data
cobalt-price history --days 30

# Generate statistics
cobalt-price stats --days 7

# Create visualizations
cobalt-price chart --type dashboard --days 30

# Generate reports
cobalt-price report --format html --days 30

# Set up price alerts
cobalt-price alert --type above --threshold 20.0 --email your@email.com

# Update all prices
cobalt-price update
```

#### Python Library

```python
from cobalt_price import CobaltPriceTracker

# Initialize tracker
tracker = CobaltPriceTracker()

# Fetch current prices
prices = tracker.fetch_current_prices()

# Get historical data
historical = tracker.get_historical_prices(days=30)

# Get statistics
stats = tracker.get_price_statistics(days=30)

# Update and store prices
result = tracker.update_prices()
```

#### Web API

Start the web server:
```bash
# Using the CLI
cobalt-price web --host 0.0.0.0 --port 8000

# Or directly with Python
python -m cobalt_price.web_api
```

Access the API:
- **API Documentation**: http://localhost:8000/docs
- **Current Prices**: http://localhost:8000/prices/current
- **Historical Data**: http://localhost:8000/prices/history?days=30
- **Statistics**: http://localhost:8000/prices/stats
- **Charts**: http://localhost:8000/charts/dashboard?days=30

## Configuration

### Environment Variables

Create a `.env` file in the project root:

```env
# API Keys
METAL_PRICE_API_KEY=your_metal_price_api_key_here
ALPHA_VANTAGE_API_KEY=your_alpha_vantage_key_here

# Database
DATABASE_URL=sqlite:///cobalt_prices.db

# Update Settings
UPDATE_INTERVAL=60  # minutes

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/cobalt_price.log

# Web Interface
WEB_HOST=127.0.0.1
WEB_PORT=8000

# Email Notifications (optional)
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
EMAIL_USER=your_email@example.com
EMAIL_PASSWORD=your_app_password
ALERT_EMAIL=alerts@example.com
```

### API Keys

#### Metal Price API (metalpriceapi.com)
1. Sign up at [metalpriceapi.com](https://metalpriceapi.com/)
2. Get your API key from the dashboard
3. Add it to your `.env` file as `METAL_PRICE_API_KEY`

#### Alpha Vantage (optional)
1. Sign up at [alphavantage.co](https://www.alphavantage.co/)
2. Get your free API key
3. Add it to your `.env` file as `ALPHA_VANTAGE_API_KEY`

## Data Sources

### Primary Sources

1. **Metal Price API**: Real-time cobalt prices from metalpriceapi.com
   - High reliability and accuracy
   - Multiple cobalt symbols supported (COB, COBALT, XCO)
   - Historical data available

2. **Web Scraping**: Backup data from financial websites
   - investing.com
   - metalary.com
   - infomine.com

3. **Mock Source**: For testing and development
   - Generates realistic price fluctuations
   - Always available for testing

## Architecture

### Project Structure

```
Cobalt-Price/
├── src/cobalt_price/           # Main package
│   ├── __init__.py            # Package initialization
│   ├── core.py                # Core tracker functionality
│   ├── config.py              # Configuration management
│   ├── models.py              # Data models
│   ├── cli.py                 # Command line interface
│   ├── web_api.py             # FastAPI web interface
│   ├── data_sources/          # Data source implementations
│   │   ├── base.py            # Abstract base class
│   │   ├── metals_api.py      # Metal Price API integration
│   │   ├── web_scraper.py     # Web scraping implementation
│   │   └── mock_source.py     # Mock data for testing
│   ├── storage/               # Data storage
│   │   └── database.py        # Database management
│   └── visualization/         # Charts and reports
│       ├── charts.py          # Chart generation
│       └── reports.py         # Report generation
├── tests/                     # Test suite
├── docs/                      # Documentation
├── config/                    # Configuration files
├── requirements.txt           # Python dependencies
├── pyproject.toml            # Project configuration
└── README.md                 # This file
```

### Key Components

1. **CobaltPriceTracker**: Main class that orchestrates all functionality
2. **DataSource**: Abstract base for all data sources
3. **DatabaseManager**: Handles all database operations
4. **ChartGenerator**: Creates visualizations
5. **ReportGenerator**: Generates analysis reports

## API Reference

### CLI Commands

| Command | Description | Options |
|---------|-------------|---------|
| `fetch` | Get current prices | `--save`, `--format` |
| `history` | Show historical data | `--days`, `--source`, `--format` |
| `stats` | Display statistics | `--days` |
| `chart` | Generate charts | `--days`, `--type`, `--output` |
| `report` | Create reports | `--days`, `--format`, `--output` |
| `update` | Update all prices | None |
| `alert` | Create price alert | `--type`, `--threshold`, `--email` |
| `check-alerts` | Check triggered alerts | None |
| `info` | System information | None |

### Web API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | API information |
| `/prices/current` | GET | Current prices |
| `/prices/history` | GET | Historical data |
| `/prices/latest` | GET | Latest price |
| `/prices/stats` | GET | Price statistics |
| `/prices/update` | POST | Update prices |
| `/charts/{type}` | GET | Generate charts |
| `/reports/{format}` | GET | Generate reports |
| `/alerts` | GET/POST | Manage alerts |
| `/alerts/{id}` | DELETE | Delete alert |
| `/info` | GET | System info |

## Development

### Setup Development Environment

```bash
# Clone repository
git clone git@github.com:luizpersechini/Cobalt-Price.git
cd Cobalt-Price

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install development dependencies
pip install -r requirements.txt
pip install -e ".[dev]"

# Run tests
pytest tests/

# Format code
black src/

# Type checking
mypy src/
```

### Adding New Data Sources

1. Create a new class inheriting from `DataSource`
2. Implement `get_current_price()` and `is_available()` methods
3. Add the source to `CobaltPriceTracker._initialize_data_sources()`

Example:
```python
from .base import DataSource
from ..models import PriceData

class NewDataSource(DataSource):
    def __init__(self):
        super().__init__("NewSource")
    
    def get_current_price(self):
        # Implementation here
        return PriceData(...)
    
    def is_available(self):
        # Check if source is available
        return True
```

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=cobalt_price

# Run specific test file
pytest tests/test_core.py

# Run with verbose output
pytest -v
```

## Deployment

### Docker Deployment

```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY . .
RUN pip install -r requirements.txt
RUN pip install -e .

EXPOSE 8000
CMD ["python", "-m", "cobalt_price.web_api"]
```

### Systemd Service

Create `/etc/systemd/system/cobalt-price.service`:

```ini
[Unit]
Description=Cobalt Price Tracker
After=network.target

[Service]
Type=simple
User=cobalt
WorkingDirectory=/opt/cobalt-price
Environment=PATH=/opt/cobalt-price/venv/bin
ExecStart=/opt/cobalt-price/venv/bin/python -m cobalt_price.web_api
Restart=always

[Install]
WantedBy=multi-user.target
```

### Cron Job for Regular Updates

```bash
# Add to crontab
crontab -e

# Update prices every hour
0 * * * * /path/to/venv/bin/cobalt-price update
```

## Monitoring and Maintenance

### Log Files

- Application logs: `logs/cobalt_price.log`
- Web server logs: Check console output or configure logging

### Database Maintenance

```bash
# Check database statistics
cobalt-price info

# Clean old data (keep last 365 days)
python -c "
from cobalt_price.storage.database import DatabaseManager
db = DatabaseManager()
deleted = db.delete_old_prices(365)
print(f'Deleted {deleted} old records')
"
```

### Health Checks

```bash
# Check system status
cobalt-price info

# Test data sources
cobalt-price fetch

# Verify API
curl http://localhost:8000/info
```

## Troubleshooting

### Common Issues

1. **API Key Issues**
   - Verify API keys in `.env` file
   - Check API key validity and quotas
   - Ensure proper environment variable names

2. **Database Issues**
   - Check database file permissions
   - Verify SQLite installation
   - Check disk space

3. **Network Issues**
   - Verify internet connection
   - Check firewall settings
   - Test API endpoints manually

4. **Import Errors**
   - Ensure all dependencies are installed
   - Check Python path configuration
   - Verify package installation

### Debug Mode

Enable debug logging:
```bash
export LOG_LEVEL=DEBUG
cobalt-price fetch
```

Or in Python:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Contribution Guidelines

- Follow PEP 8 style guidelines
- Add tests for new functionality
- Update documentation as needed
- Ensure all tests pass before submitting

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Changelog

### Version 0.1.0 (Initial Release)
- Multi-source data collection
- CLI and Web API interfaces
- Visualization and reporting
- Alert system
- Comprehensive documentation

## Support

- **Issues**: [GitHub Issues](https://github.com/luizpersechini/Cobalt-Price/issues)
- **Documentation**: See `/docs` directory
- **Email**: luizpersechini@example.com

## Acknowledgments

- [Metal Price API](https://metalpriceapi.com/) for real-time price data
- [FastAPI](https://fastapi.tiangolo.com/) for the web framework
- [Click](https://click.palletsprojects.com/) for the CLI interface
- [Matplotlib](https://matplotlib.org/) and [Seaborn](https://seaborn.pydata.org/) for visualizations