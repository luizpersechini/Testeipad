"""Tests for the core CobaltPriceTracker functionality."""

import pytest
from unittest.mock import Mock, patch
from datetime import datetime, timedelta
from decimal import Decimal

from cobalt_price.core import CobaltPriceTracker
from cobalt_price.models import PriceData


class TestCobaltPriceTracker:
    """Test cases for CobaltPriceTracker class."""
    
    @pytest.fixture
    def tracker(self):
        """Create a CobaltPriceTracker instance for testing."""
        return CobaltPriceTracker()
    
    @pytest.fixture
    def sample_price_data(self):
        """Create sample price data for testing."""
        return [
            PriceData(
                price=Decimal("15.50"),
                currency="USD",
                unit="lb",
                source="TestSource",
                timestamp=datetime.now(),
                metadata={"test": True}
            ),
            PriceData(
                price=Decimal("15.75"),
                currency="USD",
                unit="lb",
                source="TestSource2",
                timestamp=datetime.now(),
                metadata={"test": True}
            )
        ]
    
    def test_tracker_initialization(self, tracker):
        """Test that tracker initializes correctly."""
        assert tracker is not None
        assert tracker.logger is not None
        assert tracker.db_manager is not None
        assert tracker.data_sources is not None
        assert len(tracker.data_sources) > 0
    
    @patch('cobalt_price.core.CobaltPriceTracker._initialize_data_sources')
    def test_data_source_initialization(self, mock_init_sources, tracker):
        """Test data source initialization."""
        mock_sources = [Mock(), Mock()]
        mock_init_sources.return_value = mock_sources
        
        new_tracker = CobaltPriceTracker()
        mock_init_sources.assert_called_once()
    
    def test_fetch_current_prices_success(self, tracker, sample_price_data):
        """Test successful price fetching."""
        # Mock data sources
        mock_source1 = Mock()
        mock_source1.name = "MockSource1"
        mock_source1.get_current_price.return_value = sample_price_data[0]
        
        mock_source2 = Mock()
        mock_source2.name = "MockSource2"
        mock_source2.get_current_price.return_value = sample_price_data[1]
        
        tracker.data_sources = [mock_source1, mock_source2]
        
        prices = tracker.fetch_current_prices()
        
        assert len(prices) == 2
        assert all(isinstance(price, PriceData) for price in prices)
        mock_source1.get_current_price.assert_called_once()
        mock_source2.get_current_price.assert_called_once()
    
    def test_fetch_current_prices_with_failures(self, tracker, sample_price_data):
        """Test price fetching with some source failures."""
        mock_source1 = Mock()
        mock_source1.name = "MockSource1"
        mock_source1.get_current_price.side_effect = Exception("API Error")
        
        mock_source2 = Mock()
        mock_source2.name = "MockSource2"
        mock_source2.get_current_price.return_value = sample_price_data[0]
        
        tracker.data_sources = [mock_source1, mock_source2]
        
        prices = tracker.fetch_current_prices()
        
        assert len(prices) == 1
        assert prices[0].source == "TestSource"
    
    def test_fetch_current_prices_empty_result(self, tracker):
        """Test price fetching when no sources return data."""
        mock_source = Mock()
        mock_source.name = "MockSource"
        mock_source.get_current_price.return_value = None
        
        tracker.data_sources = [mock_source]
        
        prices = tracker.fetch_current_prices()
        
        assert len(prices) == 0
    
    def test_store_prices(self, tracker, sample_price_data):
        """Test storing prices in the database."""
        with patch.object(tracker.db_manager, 'save_prices') as mock_save:
            tracker.store_prices(sample_price_data)
            mock_save.assert_called_once_with(sample_price_data)
    
    def test_store_prices_error(self, tracker, sample_price_data):
        """Test error handling when storing prices."""
        with patch.object(tracker.db_manager, 'save_prices') as mock_save:
            mock_save.side_effect = Exception("Database error")
            
            with pytest.raises(Exception, match="Database error"):
                tracker.store_prices(sample_price_data)
    
    def test_get_historical_prices(self, tracker):
        """Test retrieving historical prices."""
        with patch.object(tracker.db_manager, 'get_prices_since') as mock_get:
            mock_prices = [Mock(), Mock()]
            mock_get.return_value = mock_prices
            
            prices = tracker.get_historical_prices(days=7, source="TestSource")
            
            assert prices == mock_prices
            mock_get.assert_called_once()
            
            # Check that the date argument is approximately correct
            call_args = mock_get.call_args[0]
            expected_date = datetime.now() - timedelta(days=7)
            actual_date = call_args[0]
            
            # Allow for small time differences in test execution
            assert abs((expected_date - actual_date).total_seconds()) < 60
    
    def test_get_latest_price(self, tracker):
        """Test retrieving the latest price."""
        with patch.object(tracker.db_manager, 'get_latest_price') as mock_get:
            mock_price = Mock()
            mock_get.return_value = mock_price
            
            price = tracker.get_latest_price(source="TestSource")
            
            assert price == mock_price
            mock_get.assert_called_once_with("TestSource")
    
    def test_get_price_statistics_empty(self, tracker):
        """Test price statistics with no data."""
        with patch.object(tracker, 'get_historical_prices') as mock_get:
            mock_get.return_value = []
            
            stats = tracker.get_price_statistics(days=30)
            
            assert stats == {}
    
    def test_get_price_statistics_with_data(self, tracker):
        """Test price statistics calculation."""
        # Create mock price objects
        mock_prices = []
        for i, price_val in enumerate([15.0, 15.5, 16.0, 15.25, 15.75]):
            mock_price = Mock()
            mock_price.price = Decimal(str(price_val))
            mock_price.timestamp = datetime.now() - timedelta(days=i)
            mock_prices.append(mock_price)
        
        with patch.object(tracker, 'get_historical_prices') as mock_get:
            mock_get.return_value = mock_prices
            
            stats = tracker.get_price_statistics(days=30)
            
            assert 'count' in stats
            assert 'min' in stats
            assert 'max' in stats
            assert 'avg' in stats
            assert 'latest' in stats
            
            assert stats['count'] == 5
            assert stats['min'] == 15.0
            assert stats['max'] == 16.0
            assert stats['latest'] == 15.75  # Last price in the list
    
    def test_update_prices_success(self, tracker, sample_price_data):
        """Test successful price update."""
        with patch.object(tracker, 'fetch_current_prices') as mock_fetch, \
             patch.object(tracker, 'store_prices') as mock_store:
            
            mock_fetch.return_value = sample_price_data
            
            result = tracker.update_prices()
            
            assert result['success'] is True
            assert result['prices_fetched'] == 2
            assert 'duration_seconds' in result
            assert 'timestamp' in result
            assert 'sources' in result
            
            mock_fetch.assert_called_once()
            mock_store.assert_called_once_with(sample_price_data)
    
    def test_update_prices_failure(self, tracker):
        """Test price update failure handling."""
        with patch.object(tracker, 'fetch_current_prices') as mock_fetch:
            mock_fetch.side_effect = Exception("Network error")
            
            result = tracker.update_prices()
            
            assert result['success'] is False
            assert 'error' in result
            assert result['error'] == "Network error"
    
    def test_calculate_change_insufficient_data(self, tracker):
        """Test price change calculation with insufficient data."""
        prices = [Mock()]  # Only one price
        change = tracker._calculate_change(prices, 1)
        assert change is None
    
    def test_calculate_change_no_recent_data(self, tracker):
        """Test price change calculation with no recent data."""
        # Create prices that are all older than the cutoff
        old_date = datetime.now() - timedelta(days=10)
        prices = []
        for i in range(3):
            mock_price = Mock()
            mock_price.timestamp = old_date - timedelta(days=i)
            mock_price.price = Decimal("15.0")
            prices.append(mock_price)
        
        change = tracker._calculate_change(prices, 1)  # Look for 1-day change
        assert change is None
    
    def test_calculate_change_valid_calculation(self, tracker):
        """Test valid price change calculation."""
        # Create recent prices
        now = datetime.now()
        prices = []
        price_values = [15.0, 15.5, 16.0]  # 6.67% increase from first to last
        
        for i, price_val in enumerate(price_values):
            mock_price = Mock()
            mock_price.timestamp = now - timedelta(hours=i)
            mock_price.price = Decimal(str(price_val))
            prices.append(mock_price)
        
        change = tracker._calculate_change(prices, 1)  # 1-day change
        
        assert change is not None
        # Should be approximately 6.67% increase
        assert 6.0 < change < 7.0
    
    @pytest.mark.integration
    def test_full_workflow(self, tracker):
        """Integration test of the full workflow."""
        # This test requires actual data sources to be available
        # Skip if no real data sources are configured
        if not any(hasattr(source, 'api_key') for source in tracker.data_sources):
            pytest.skip("No real data sources configured for integration test")
        
        # Test the full workflow
        result = tracker.update_prices()
        
        if result['success']:
            # If update was successful, test other operations
            latest = tracker.get_latest_price()
            assert latest is not None
            
            historical = tracker.get_historical_prices(days=1)
            assert len(historical) >= 0
            
            stats = tracker.get_price_statistics(days=1)
            if stats:  # Only test if we have data
                assert 'count' in stats
                assert 'avg' in stats