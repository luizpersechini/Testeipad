"""Mock data source for testing and development."""

import random
from typing import Optional, Union, List
from decimal import Decimal
from datetime import datetime, timedelta

from .base import DataSource
from ..models import PriceData


class MockSource(DataSource):
    """Mock data source for testing purposes."""
    
    def __init__(self):
        super().__init__("MockSource")
        # Base price around current cobalt market price (approximate)
        self.base_price = Decimal("15.50")  # USD per pound
        self.last_price = self.base_price
    
    def get_current_price(self) -> Optional[Union[PriceData, List[PriceData]]]:
        """Generate mock cobalt price data."""
        try:
            # Generate realistic price fluctuation (±5% from last price)
            variation = Decimal(str(random.uniform(-0.05, 0.05)))
            new_price = self.last_price * (Decimal("1") + variation)
            
            # Keep price within reasonable bounds ($10-$25 per pound)
            new_price = max(Decimal("10.00"), min(Decimal("25.00"), new_price))
            self.last_price = new_price
            
            return PriceData(
                price=new_price,
                currency="USD",
                unit="lb",
                source=self.name,
                timestamp=datetime.now(),
                metadata={
                    "mock_data": True,
                    "variation_percent": float(variation * 100),
                    "base_price": float(self.base_price)
                }
            )
            
        except Exception as e:
            raise Exception(f"Error generating mock price: {str(e)}")
    
    def get_historical_mock_prices(self, days: int = 30) -> List[PriceData]:
        """Generate mock historical price data."""
        prices = []
        current_price = self.base_price
        
        for i in range(days):
            # Generate daily variation
            variation = Decimal(str(random.uniform(-0.03, 0.03)))
            current_price = current_price * (Decimal("1") + variation)
            
            # Keep within bounds
            current_price = max(Decimal("10.00"), min(Decimal("25.00"), current_price))
            
            # Create timestamp for i days ago
            timestamp = datetime.now().replace(
                hour=9, minute=0, second=0, microsecond=0
            ) - timedelta(days=days - i - 1)
            
            prices.append(PriceData(
                price=current_price,
                currency="USD",
                unit="lb",
                source=self.name,
                timestamp=timestamp,
                metadata={
                    "mock_data": True,
                    "historical": True,
                    "days_ago": days - i - 1
                }
            ))
        
        return prices
    
    def is_available(self) -> bool:
        """Mock source is always available."""
        return True