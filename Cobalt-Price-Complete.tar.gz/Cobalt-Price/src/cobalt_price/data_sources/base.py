"""Base class for data sources."""

from abc import ABC, abstractmethod
from typing import Union, List, Optional
from ..models import PriceData


class DataSource(ABC):
    """Abstract base class for cobalt price data sources."""
    
    def __init__(self, name: str):
        self.name = name
    
    @abstractmethod
    def get_current_price(self) -> Optional[Union[PriceData, List[PriceData]]]:
        """
        Fetch current cobalt price(s) from the data source.
        
        Returns:
            Either a single PriceData object or a list of PriceData objects,
            or None if no data is available.
        """
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        """
        Check if the data source is currently available.
        
        Returns:
            True if the data source can be accessed, False otherwise.
        """
        pass
    
    def __str__(self) -> str:
        return f"{self.__class__.__name__}({self.name})"
    
    def __repr__(self) -> str:
        return self.__str__()