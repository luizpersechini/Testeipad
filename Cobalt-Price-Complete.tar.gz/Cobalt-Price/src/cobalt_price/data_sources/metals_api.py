"""Metal Price API data source for cobalt prices."""

from typing import Optional, Union, List
from decimal import Decimal
from datetime import datetime

try:
    from metalpriceapi.client import Client
    METALPRICEAPI_AVAILABLE = True
except ImportError:
    METALPRICEAPI_AVAILABLE = False
    Client = None

from .base import DataSource
from ..models import PriceData


class MetalPriceAPISource(DataSource):
    """Data source for Metal Price API (metalpriceapi.com)."""
    
    def __init__(self, api_key: str):
        super().__init__("MetalPriceAPI")
        self.api_key = api_key
        
        if not METALPRICEAPI_AVAILABLE:
            raise ImportError("metalpriceapi library not installed. Install with: pip install metalpriceapi")
        
        self.client = Client(api_key)
    
    def get_current_price(self) -> Optional[Union[PriceData, List[PriceData]]]:
        """Fetch current cobalt price from Metal Price API."""
        try:
            # Fetch live rates for cobalt
            # Common cobalt symbols: COB, COBALT, XCO
            cobalt_symbols = ['COB', 'COBALT', 'XCO']
            
            for symbol in cobalt_symbols:
                try:
                    # Fetch live rates for the current symbol
                    response = self.client.fetchLive(base='USD', currencies=[symbol])
                    
                    if response.get('success', False) and 'rates' in response:
                        rates = response['rates']
                        if symbol in rates:
                            # Price is typically per ounce, convert to per pound
                            price_per_oz = Decimal(str(rates[symbol]))
                            price_per_lb = price_per_oz * Decimal("16")  # 1 lb ≈ 16 oz
                            
                            return PriceData(
                                price=price_per_lb,
                                currency="USD",
                                unit="lb",
                                source=self.name,
                                timestamp=datetime.now(),
                                metadata={
                                    "api_response": response,
                                    "symbol_used": symbol,
                                    "original_price_per_oz": float(price_per_oz),
                                    "timestamp": response.get('timestamp')
                                }
                            )
                except Exception as e:
                    # Try next symbol if this one fails
                    continue
            
            # If no symbol worked, return None
            return None
            
        except Exception as e:
            raise Exception(f"Error fetching from Metal Price API: {str(e)}")
    
    def get_historical_price(self, date: str) -> Optional[PriceData]:
        """
        Fetch historical cobalt price for a specific date.
        
        Args:
            date: Date in YYYY-MM-DD format
            
        Returns:
            PriceData object or None if no data available
        """
        try:
            cobalt_symbols = ['COB', 'COBALT', 'XCO']
            
            for symbol in cobalt_symbols:
                try:
                    response = self.client.fetchHistorical(date=date, base='USD', currencies=[symbol])
                    
                    if response.get('success', False) and 'rates' in response:
                        rates = response['rates']
                        if symbol in rates:
                            price_per_oz = Decimal(str(rates[symbol]))
                            price_per_lb = price_per_oz * Decimal("16")
                            
                            return PriceData(
                                price=price_per_lb,
                                currency="USD",
                                unit="lb",
                                source=self.name,
                                timestamp=datetime.strptime(date, '%Y-%m-%d'),
                                metadata={
                                    "api_response": response,
                                    "symbol_used": symbol,
                                    "original_price_per_oz": float(price_per_oz),
                                    "historical_date": date
                                }
                            )
                except Exception:
                    continue
            
            return None
            
        except Exception as e:
            raise Exception(f"Error fetching historical data from Metal Price API: {str(e)}")
    
    def get_supported_symbols(self) -> Optional[dict]:
        """Get all supported symbols from the API."""
        try:
            response = self.client.fetchSymbols()
            return response
        except Exception as e:
            raise Exception(f"Error fetching symbols from Metal Price API: {str(e)}")
    
    def is_available(self) -> bool:
        """Check if Metal Price API is available."""
        if not METALPRICEAPI_AVAILABLE:
            return False
            
        try:
            # Test with a common symbol like gold (XAU)
            response = self.client.fetchLive(base='USD', currencies=['XAU'])
            return response.get('success', False)
            
        except Exception:
            return False