"""Web scraper data source for cobalt prices."""

import requests
from bs4 import BeautifulSoup
from typing import Optional, Union, List
from decimal import Decimal
from datetime import datetime
import re

from .base import DataSource
from ..models import PriceData


class WebScraperSource(DataSource):
    """Data source that scrapes cobalt prices from various websites."""
    
    def __init__(self):
        super().__init__("WebScraper")
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        })
    
    def get_current_price(self) -> Optional[Union[PriceData, List[PriceData]]]:
        """Fetch current cobalt price by web scraping."""
        prices = []
        
        # Try multiple sources
        sources = [
            self._scrape_investing_com,
            self._scrape_metalary,
            self._scrape_infomine
        ]
        
        for scraper_func in sources:
            try:
                price_data = scraper_func()
                if price_data:
                    prices.append(price_data)
            except Exception as e:
                # Log error but continue with other sources
                continue
        
        return prices if prices else None
    
    def _scrape_investing_com(self) -> Optional[PriceData]:
        """Scrape cobalt price from investing.com."""
        try:
            url = "https://www.investing.com/commodities/cobalt"
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for price elements (this may need adjustment based on site structure)
            price_elements = soup.find_all(['span', 'div'], {'class': re.compile(r'.*price.*', re.I)})
            
            for element in price_elements:
                text = element.get_text().strip()
                # Look for price pattern (number with optional comma/decimal)
                price_match = re.search(r'(\d{1,3}(?:,\d{3})*(?:\.\d{2})?)', text)
                if price_match:
                    price_str = price_match.group(1).replace(',', '')
                    price = Decimal(price_str)
                    
                    return PriceData(
                        price=price,
                        currency="USD",
                        unit="lb",
                        source=f"{self.name}_investing",
                        timestamp=datetime.now(),
                        metadata={
                            "url": url,
                            "scraped_text": text
                        }
                    )
            
            return None
            
        except Exception as e:
            raise Exception(f"Error scraping investing.com: {str(e)}")
    
    def _scrape_metalary(self) -> Optional[PriceData]:
        """Scrape cobalt price from metalary.com."""
        try:
            url = "https://metalary.com/cobalt-price/"
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for price information
            price_elements = soup.find_all(['div', 'span', 'td'], text=re.compile(r'\$\d+'))
            
            for element in price_elements:
                text = element.get_text().strip()
                # Extract price from text like "$XX.XX"
                price_match = re.search(r'\$(\d+(?:\.\d{2})?)', text)
                if price_match:
                    price = Decimal(price_match.group(1))
                    
                    return PriceData(
                        price=price,
                        currency="USD",
                        unit="lb",
                        source=f"{self.name}_metalary",
                        timestamp=datetime.now(),
                        metadata={
                            "url": url,
                            "scraped_text": text
                        }
                    )
            
            return None
            
        except Exception as e:
            raise Exception(f"Error scraping metalary.com: {str(e)}")
    
    def _scrape_infomine(self) -> Optional[PriceData]:
        """Scrape cobalt price from infomine.com."""
        try:
            url = "https://www.infomine.com/investment/metal-prices/cobalt/"
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for price tables or elements
            price_elements = soup.find_all(['td', 'span', 'div'], text=re.compile(r'\d+\.\d+'))
            
            for element in price_elements:
                text = element.get_text().strip()
                # Look for decimal price pattern
                price_match = re.search(r'(\d+\.\d+)', text)
                if price_match and 'cobalt' in soup.get_text().lower():
                    price = Decimal(price_match.group(1))
                    
                    return PriceData(
                        price=price,
                        currency="USD",
                        unit="lb",
                        source=f"{self.name}_infomine",
                        timestamp=datetime.now(),
                        metadata={
                            "url": url,
                            "scraped_text": text
                        }
                    )
            
            return None
            
        except Exception as e:
            raise Exception(f"Error scraping infomine.com: {str(e)}")
    
    def is_available(self) -> bool:
        """Check if web scraping is available."""
        try:
            # Test with a simple request to a reliable site
            response = self.session.get("https://httpbin.org/user-agent", timeout=10)
            return response.status_code == 200
        except Exception:
            return False