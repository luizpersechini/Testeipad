"""Command-line interface for the Cobalt Price Tracker."""

import click
import json
from datetime import datetime, timedelta
from pathlib import Path

from .core import CobaltPriceTracker
from .visualization.charts import ChartGenerator
from .visualization.reports import ReportGenerator
from .config import config


@click.group()
@click.version_option()
def main():
    """Cobalt Price Tracker - Monitor and analyze cobalt prices from multiple sources."""
    pass


@main.command()
@click.option('--save', is_flag=True, help='Save prices to database')
@click.option('--format', 'output_format', default='table', 
              type=click.Choice(['table', 'json', 'csv']), 
              help='Output format')
def fetch(save, output_format):
    """Fetch current cobalt prices from all available sources."""
    tracker = CobaltPriceTracker()
    
    click.echo("Fetching current cobalt prices...")
    prices = tracker.fetch_current_prices()
    
    if not prices:
        click.echo("No prices retrieved.")
        return
    
    if save:
        tracker.store_prices(prices)
        click.echo(f"Saved {len(prices)} price records to database.")
    
    # Display results
    if output_format == 'table':
        click.echo(f"\nFound {len(prices)} price(s):")
        click.echo("-" * 80)
        click.echo(f"{'Source':<20} {'Price':<10} {'Currency':<8} {'Unit':<6} {'Timestamp':<20}")
        click.echo("-" * 80)
        
        for price in prices:
            click.echo(f"{price.source:<20} ${price.price:<9.2f} {price.currency:<8} {price.unit:<6} {price.timestamp}")
    
    elif output_format == 'json':
        price_data = []
        for price in prices:
            price_data.append({
                'source': price.source,
                'price': float(price.price),
                'currency': price.currency,
                'unit': price.unit,
                'timestamp': price.timestamp.isoformat()
            })
        click.echo(json.dumps(price_data, indent=2))
    
    elif output_format == 'csv':
        click.echo("source,price,currency,unit,timestamp")
        for price in prices:
            click.echo(f"{price.source},{price.price},{price.currency},{price.unit},{price.timestamp}")


@main.command()
@click.option('--days', default=30, help='Number of days of historical data')
@click.option('--source', help='Filter by specific data source')
@click.option('--format', 'output_format', default='table',
              type=click.Choice(['table', 'json', 'csv']),
              help='Output format')
def history(days, source, output_format):
    """Show historical price data."""
    tracker = CobaltPriceTracker()
    
    click.echo(f"Retrieving {days} days of historical data...")
    prices = tracker.get_historical_prices(days, source)
    
    if not prices:
        click.echo("No historical data found.")
        return
    
    if output_format == 'table':
        click.echo(f"\nFound {len(prices)} historical price records:")
        click.echo("-" * 80)
        click.echo(f"{'Date':<12} {'Source':<20} {'Price':<10} {'Currency':<8} {'Unit':<6}")
        click.echo("-" * 80)
        
        for price in prices[-20:]:  # Show last 20 records
            date_str = price.timestamp.strftime('%Y-%m-%d')
            click.echo(f"{date_str:<12} {price.source:<20} ${price.price:<9.2f} {price.currency:<8} {price.unit:<6}")
        
        if len(prices) > 20:
            click.echo(f"... and {len(prices) - 20} more records")
    
    elif output_format == 'json':
        price_data = []
        for price in prices:
            price_data.append({
                'id': price.id,
                'source': price.source,
                'price': float(price.price),
                'currency': price.currency,
                'unit': price.unit,
                'timestamp': price.timestamp.isoformat()
            })
        click.echo(json.dumps(price_data, indent=2))


@main.command()
@click.option('--days', default=30, help='Number of days to analyze')
def stats(days):
    """Show price statistics and analysis."""
    tracker = CobaltPriceTracker()
    
    click.echo(f"Analyzing price statistics for the last {days} days...")
    statistics = tracker.get_price_statistics(days)
    
    if not statistics:
        click.echo("No data available for analysis.")
        return
    
    click.echo("\n" + "="*50)
    click.echo("COBALT PRICE STATISTICS")
    click.echo("="*50)
    
    click.echo(f"Data points: {statistics.get('count', 'N/A')}")
    click.echo(f"Latest price: ${statistics.get('latest', 'N/A'):.2f}")
    click.echo(f"Average price: ${statistics.get('avg', 'N/A'):.2f}")
    click.echo(f"Price range: ${statistics.get('min', 'N/A'):.2f} - ${statistics.get('max', 'N/A'):.2f}")
    
    if statistics.get('change_24h') is not None:
        change_24h = statistics['change_24h']
        direction = "↑" if change_24h > 0 else "↓" if change_24h < 0 else "→"
        click.echo(f"24h change: {direction} {change_24h:+.2f}%")
    
    if statistics.get('change_7d') is not None:
        change_7d = statistics['change_7d']
        direction = "↑" if change_7d > 0 else "↓" if change_7d < 0 else "→"
        click.echo(f"7d change: {direction} {change_7d:+.2f}%")
    
    if statistics.get('change_30d') is not None:
        change_30d = statistics['change_30d']
        direction = "↑" if change_30d > 0 else "↓" if change_30d < 0 else "→"
        click.echo(f"30d change: {direction} {change_30d:+.2f}%")


@main.command()
@click.option('--days', default=30, help='Number of days of data to visualize')
@click.option('--type', 'chart_type', default='timeline',
              type=click.Choice(['timeline', 'comparison', 'statistics', 'dashboard']),
              help='Type of chart to generate')
@click.option('--output', help='Output file path')
def chart(days, chart_type, output):
    """Generate price charts and visualizations."""
    tracker = CobaltPriceTracker()
    chart_gen = ChartGenerator()
    
    click.echo(f"Generating {chart_type} chart for the last {days} days...")
    prices = tracker.get_historical_prices(days)
    
    if not prices:
        click.echo("No data available for chart generation.")
        return
    
    try:
        output_path = Path(output) if output else None
        
        if chart_type == 'timeline':
            saved_path = chart_gen.create_price_timeline(prices, save_path=output_path)
        elif chart_type == 'comparison':
            saved_path = chart_gen.create_price_comparison(prices, save_path=output_path)
        elif chart_type == 'statistics':
            saved_path = chart_gen.create_price_statistics(prices, save_path=output_path)
        elif chart_type == 'dashboard':
            saved_path = chart_gen.create_dashboard(prices, save_path=output_path)
        
        click.echo(f"Chart saved to: {saved_path}")
        
    except Exception as e:
        click.echo(f"Error generating chart: {str(e)}")


@main.command()
@click.option('--days', default=30, help='Number of days to include in report')
@click.option('--format', 'report_format', default='json',
              type=click.Choice(['json', 'html', 'csv']),
              help='Report format')
@click.option('--output', help='Output file path')
def report(days, report_format, output):
    """Generate comprehensive price analysis report."""
    tracker = CobaltPriceTracker()
    report_gen = ReportGenerator()
    
    click.echo(f"Generating {report_format} report for the last {days} days...")
    prices = tracker.get_historical_prices(days)
    
    if not prices:
        click.echo("No data available for report generation.")
        return
    
    try:
        if report_format == 'json':
            report_data = report_gen.generate_summary_report(prices, days)
            if output:
                saved_path = report_gen.save_report_json(report_data, output)
            else:
                saved_path = report_gen.save_report_json(report_data)
            
        elif report_format == 'html':
            saved_path = report_gen.generate_html_report(prices, days)
            
        elif report_format == 'csv':
            filename = output if output else None
            saved_path = report_gen.generate_csv_export(prices, filename)
        
        click.echo(f"Report saved to: {saved_path}")
        
    except Exception as e:
        click.echo(f"Error generating report: {str(e)}")


@main.command()
def update():
    """Update price data from all sources."""
    tracker = CobaltPriceTracker()
    
    click.echo("Updating price data from all sources...")
    result = tracker.update_prices()
    
    if result['success']:
        click.echo(f"✓ Successfully updated prices:")
        click.echo(f"  - Fetched {result['prices_fetched']} prices")
        click.echo(f"  - Duration: {result['duration_seconds']:.2f} seconds")
        click.echo(f"  - Sources: {', '.join(result['sources'])}")
    else:
        click.echo(f"✗ Update failed: {result['error']}")


@main.command()
@click.option('--type', 'alert_type', required=True,
              type=click.Choice(['above', 'below', 'change']),
              help='Type of alert')
@click.option('--threshold', required=True, type=float, help='Alert threshold')
@click.option('--email', help='Email address for notifications')
def alert(alert_type, threshold, email):
    """Create a price alert."""
    tracker = CobaltPriceTracker()
    
    try:
        alert_obj = tracker.db_manager.create_alert(alert_type, threshold, email=email)
        click.echo(f"✓ Created {alert_type} alert with threshold ${threshold:.2f}")
        if email:
            click.echo(f"  Notifications will be sent to: {email}")
        click.echo(f"  Alert ID: {alert_obj.id}")
        
    except Exception as e:
        click.echo(f"✗ Error creating alert: {str(e)}")


@main.command()
def check_alerts():
    """Check and display triggered alerts."""
    tracker = CobaltPriceTracker()
    
    click.echo("Checking price alerts...")
    triggered_alerts = tracker.check_alerts()
    
    if not triggered_alerts:
        click.echo("No alerts triggered.")
        return
    
    click.echo(f"Found {len(triggered_alerts)} triggered alert(s):")
    for alert in triggered_alerts:
        click.echo(f"  - {alert['alert_type'].title()} alert: threshold ${alert['threshold']:.2f}, current price ${alert['current_price']:.2f}")


@main.command()
@click.option('--host', default=None, help='Host to bind to')
@click.option('--port', default=None, type=int, help='Port to bind to')
def web(host, port):
    """Start the web API server."""
    from .web_api import run_server
    
    click.echo(f"Starting Cobalt Price Tracker web server...")
    click.echo(f"Host: {host or config.web_host}")
    click.echo(f"Port: {port or config.web_port}")
    click.echo(f"API Documentation: http://{host or config.web_host}:{port or config.web_port}/docs")
    
    try:
        run_server(host, port)
    except KeyboardInterrupt:
        click.echo("\nShutting down web server...")
    except Exception as e:
        click.echo(f"Error starting web server: {str(e)}")


@main.command()
def info():
    """Show system information and configuration."""
    click.echo("Cobalt Price Tracker - System Information")
    click.echo("=" * 50)
    
    # Database info
    tracker = CobaltPriceTracker()
    try:
        db_stats = tracker.db_manager.get_database_stats()
        click.echo(f"Database: {db_stats['database_url']}")
        click.echo(f"Total price records: {db_stats['total_prices']}")
        click.echo(f"Data sources: {', '.join(db_stats['sources']) if db_stats['sources'] else 'None'}")
        click.echo(f"Active alerts: {db_stats['active_alerts']}")
        
        if db_stats['oldest_record']:
            click.echo(f"Oldest record: {db_stats['oldest_record']}")
        if db_stats['newest_record']:
            click.echo(f"Newest record: {db_stats['newest_record']}")
            
    except Exception as e:
        click.echo(f"Database error: {str(e)}")
    
    # Configuration
    click.echo(f"\nConfiguration:")
    click.echo(f"Update interval: {config.update_interval} minutes")
    click.echo(f"Log level: {config.log_level}")
    click.echo(f"Data directory: {config.data_dir}")
    
    # API keys status
    click.echo(f"\nAPI Keys:")
    click.echo(f"Metal Price API: {'✓ Configured' if config.metal_price_api_key else '✗ Not configured'}")
    click.echo(f"Alpha Vantage: {'✓ Configured' if config.alpha_vantage_api_key else '✗ Not configured'}")


if __name__ == '__main__':
    main()