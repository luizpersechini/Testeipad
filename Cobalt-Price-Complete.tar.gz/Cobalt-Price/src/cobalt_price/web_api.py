"""Web API for the Cobalt Price Tracker using FastAPI."""

from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from fastapi import FastAPI, HTTPException, Query, BackgroundTasks
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel
import uvicorn

from .core import CobaltPriceTracker
from .visualization.charts import ChartGenerator
from .visualization.reports import ReportGenerator
from .config import config


# Pydantic models for API responses
class PriceResponse(BaseModel):
    id: Optional[int]
    price: float
    currency: str
    unit: str
    source: str
    timestamp: datetime
    
    class Config:
        from_attributes = True


class PriceStatistics(BaseModel):
    count: int
    min: float
    max: float
    avg: float
    latest: Optional[float]
    change_24h: Optional[float]
    change_7d: Optional[float]
    change_30d: Optional[float]


class UpdateResult(BaseModel):
    success: bool
    prices_fetched: int
    duration_seconds: float
    timestamp: str
    sources: List[str]
    error: Optional[str] = None


class AlertRequest(BaseModel):
    alert_type: str
    threshold: float
    currency: str = "USD"
    unit: str = "lb"
    email: Optional[str] = None


# Initialize FastAPI app
app = FastAPI(
    title="Cobalt Price Tracker API",
    description="API for tracking and analyzing cobalt prices from multiple sources",
    version="0.1.0"
)

# Global tracker instance
tracker = CobaltPriceTracker()


@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "Cobalt Price Tracker API",
        "version": "0.1.0",
        "description": "Monitor and analyze cobalt prices from multiple sources",
        "endpoints": {
            "current_prices": "/prices/current",
            "historical_prices": "/prices/history",
            "statistics": "/prices/stats",
            "update": "/prices/update",
            "charts": "/charts/{chart_type}",
            "reports": "/reports/{format}",
            "alerts": "/alerts"
        }
    }


@app.get("/prices/current", response_model=List[PriceResponse])
async def get_current_prices():
    """Fetch current cobalt prices from all available sources."""
    try:
        prices = tracker.fetch_current_prices()
        
        if not prices:
            return []
        
        # Convert PriceData objects to response format
        response_prices = []
        for price in prices:
            response_prices.append(PriceResponse(
                id=None,
                price=float(price.price),
                currency=price.currency,
                unit=price.unit,
                source=price.source,
                timestamp=price.timestamp
            ))
        
        return response_prices
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/prices/history", response_model=List[PriceResponse])
async def get_historical_prices(
    days: int = Query(30, description="Number of days of historical data"),
    source: Optional[str] = Query(None, description="Filter by specific data source")
):
    """Get historical price data."""
    try:
        prices = tracker.get_historical_prices(days, source)
        
        response_prices = []
        for price in prices:
            response_prices.append(PriceResponse(
                id=price.id,
                price=float(price.price),
                currency=price.currency,
                unit=price.unit,
                source=price.source,
                timestamp=price.timestamp
            ))
        
        return response_prices
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/prices/latest", response_model=Optional[PriceResponse])
async def get_latest_price(
    source: Optional[str] = Query(None, description="Filter by specific data source")
):
    """Get the most recent price data."""
    try:
        price = tracker.get_latest_price(source)
        
        if not price:
            return None
        
        return PriceResponse(
            id=price.id,
            price=float(price.price),
            currency=price.currency,
            unit=price.unit,
            source=price.source,
            timestamp=price.timestamp
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/prices/stats", response_model=PriceStatistics)
async def get_price_statistics(
    days: int = Query(30, description="Number of days to analyze")
):
    """Get price statistics and analysis."""
    try:
        stats = tracker.get_price_statistics(days)
        
        if not stats:
            raise HTTPException(status_code=404, detail="No data available for analysis")
        
        return PriceStatistics(**stats)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/prices/update", response_model=UpdateResult)
async def update_prices(background_tasks: BackgroundTasks):
    """Update price data from all sources."""
    try:
        # Run update in background to avoid timeout
        result = tracker.update_prices()
        
        return UpdateResult(**result)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/charts/{chart_type}")
async def generate_chart(
    chart_type: str,
    days: int = Query(30, description="Number of days of data to include"),
    format: str = Query("png", description="Image format")
):
    """Generate and return price charts."""
    try:
        if chart_type not in ['timeline', 'comparison', 'statistics', 'dashboard']:
            raise HTTPException(status_code=400, detail="Invalid chart type")
        
        prices = tracker.get_historical_prices(days)
        if not prices:
            raise HTTPException(status_code=404, detail="No data available for chart generation")
        
        chart_gen = ChartGenerator()
        
        if chart_type == 'timeline':
            chart_path = chart_gen.create_price_timeline(prices)
        elif chart_type == 'comparison':
            chart_path = chart_gen.create_price_comparison(prices)
        elif chart_type == 'statistics':
            chart_path = chart_gen.create_price_statistics(prices)
        elif chart_type == 'dashboard':
            chart_path = chart_gen.create_dashboard(prices)
        
        return FileResponse(
            chart_path,
            media_type=f"image/{format}",
            filename=f"cobalt_price_{chart_type}.{format}"
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/reports/{report_format}")
async def generate_report(
    report_format: str,
    days: int = Query(30, description="Number of days to include in report")
):
    """Generate and return analysis reports."""
    try:
        if report_format not in ['json', 'html', 'csv']:
            raise HTTPException(status_code=400, detail="Invalid report format")
        
        prices = tracker.get_historical_prices(days)
        if not prices:
            raise HTTPException(status_code=404, detail="No data available for report generation")
        
        report_gen = ReportGenerator()
        
        if report_format == 'json':
            report_data = report_gen.generate_summary_report(prices, days)
            return JSONResponse(content=report_data)
        
        elif report_format == 'html':
            report_path = report_gen.generate_html_report(prices, days)
            return FileResponse(
                report_path,
                media_type="text/html",
                filename=f"cobalt_price_report.html"
            )
        
        elif report_format == 'csv':
            csv_path = report_gen.generate_csv_export(prices)
            return FileResponse(
                csv_path,
                media_type="text/csv",
                filename=f"cobalt_prices.csv"
            )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/alerts")
async def create_alert(alert_request: AlertRequest):
    """Create a new price alert."""
    try:
        if alert_request.alert_type not in ['above', 'below', 'change']:
            raise HTTPException(status_code=400, detail="Invalid alert type")
        
        alert = tracker.db_manager.create_alert(
            alert_type=alert_request.alert_type,
            threshold=alert_request.threshold,
            currency=alert_request.currency,
            unit=alert_request.unit,
            email=alert_request.email
        )
        
        return {
            "id": alert.id,
            "alert_type": alert.alert_type,
            "threshold": float(alert.threshold),
            "currency": alert.currency,
            "unit": alert.unit,
            "email": alert.email,
            "created_at": alert.created_at.isoformat()
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/alerts")
async def get_alerts():
    """Get all active alerts."""
    try:
        alerts = tracker.db_manager.get_active_alerts()
        
        alert_list = []
        for alert in alerts:
            alert_list.append({
                "id": alert.id,
                "alert_type": alert.alert_type,
                "threshold": float(alert.threshold),
                "currency": alert.currency,
                "unit": alert.unit,
                "email": alert.email,
                "created_at": alert.created_at.isoformat(),
                "last_triggered": alert.last_triggered.isoformat() if alert.last_triggered else None
            })
        
        return alert_list
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/alerts/check")
async def check_alerts():
    """Check for triggered alerts."""
    try:
        triggered_alerts = tracker.check_alerts()
        return {
            "triggered_count": len(triggered_alerts),
            "alerts": triggered_alerts
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/alerts/{alert_id}")
async def deactivate_alert(alert_id: int):
    """Deactivate a specific alert."""
    try:
        success = tracker.db_manager.deactivate_alert(alert_id)
        
        if not success:
            raise HTTPException(status_code=404, detail="Alert not found")
        
        return {"message": f"Alert {alert_id} deactivated successfully"}
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/info")
async def get_system_info():
    """Get system information and statistics."""
    try:
        db_stats = tracker.db_manager.get_database_stats()
        
        return {
            "system": {
                "version": "0.1.0",
                "update_interval": config.update_interval,
                "log_level": config.log_level
            },
            "database": db_stats,
            "api_keys": {
                "metal_price_api": bool(config.metal_price_api_key),
                "alpha_vantage": bool(config.alpha_vantage_api_key)
            }
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def run_server(host: str = None, port: int = None):
    """Run the FastAPI server."""
    host = host or config.web_host
    port = port or config.web_port
    
    uvicorn.run(
        "cobalt_price.web_api:app",
        host=host,
        port=port,
        reload=False,
        log_level=config.log_level.lower()
    )


if __name__ == "__main__":
    run_server()