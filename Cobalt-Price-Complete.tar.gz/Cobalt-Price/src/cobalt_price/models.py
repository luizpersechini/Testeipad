"""Data models for the Cobalt Price Tracker."""

from datetime import datetime
from typing import Optional
from decimal import Decimal
from pydantic import BaseModel, Field
from sqlalchemy import Column, Integer, String, DateTime, Numeric, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.sql import func

Base = declarative_base()


class PriceData(BaseModel):
    """Pydantic model for price data validation."""
    
    price: Decimal = Field(..., description="Price per unit")
    currency: str = Field("USD", description="Currency code")
    unit: str = Field("lb", description="Unit of measurement (lb, kg, tonne)")
    source: str = Field(..., description="Data source identifier")
    timestamp: datetime = Field(default_factory=datetime.now)
    metadata: Optional[dict] = Field(None, description="Additional metadata")


class CobaltPrice(Base):
    """SQLAlchemy model for storing cobalt price data."""
    
    __tablename__ = "cobalt_prices"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    price = Column(Numeric(10, 4), nullable=False)
    currency = Column(String(3), nullable=False, default="USD")
    unit = Column(String(10), nullable=False, default="lb")
    source = Column(String(50), nullable=False)
    timestamp = Column(DateTime, nullable=False, default=func.now())
    created_at = Column(DateTime, nullable=False, default=func.now())
    extra_data = Column(Text, nullable=True)
    
    def __repr__(self) -> str:
        return (
            f"<CobaltPrice(id={self.id}, price={self.price}, "
            f"currency={self.currency}, unit={self.unit}, "
            f"source={self.source}, timestamp={self.timestamp})>"
        )


class PriceAlert(Base):
    """SQLAlchemy model for price alerts."""
    
    __tablename__ = "price_alerts"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    alert_type = Column(String(20), nullable=False)  # 'above', 'below', 'change'
    threshold = Column(Numeric(10, 4), nullable=False)
    currency = Column(String(3), nullable=False, default="USD")
    unit = Column(String(10), nullable=False, default="lb")
    is_active = Column(String(10), nullable=False, default="true")
    email = Column(String(255), nullable=True)
    created_at = Column(DateTime, nullable=False, default=func.now())
    last_triggered = Column(DateTime, nullable=True)
    
    def __repr__(self) -> str:
        return (
            f"<PriceAlert(id={self.id}, type={self.alert_type}, "
            f"threshold={self.threshold}, active={self.is_active})>"
        )