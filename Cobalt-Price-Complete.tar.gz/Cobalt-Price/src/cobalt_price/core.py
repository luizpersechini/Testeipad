"""Core functionality for the Cobalt Price Tracker."""

import logging
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from decimal import Decimal

from .config import config
from .models import PriceData, CobaltPrice, PriceAlert
from .storage.database import DatabaseManager
from .data_sources.base import DataSource
from .data_sources.metals_api import MetalPriceAPISource
from .data_sources.web_scraper import WebScraperSource
from .data_sources.mock_source import MockSource


class CobaltPriceTracker:
    """Main class for tracking cobalt prices."""
    
    def __init__(self):
        self.logger = self._setup_logging()
        self.db_manager = DatabaseManager()
        self.data_sources: List[DataSource] = self._initialize_data_sources()
        
    def _setup_logging(self) -> logging.Logger:
        """Set up logging configuration."""
        logger = logging.getLogger("cobalt_price")
        logger.setLevel(getattr(logging, config.log_level.upper()))
        
        # Create logs directory if it doesn't exist
        config.logs_dir.mkdir(exist_ok=True)
        
        # File handler
        file_handler = logging.FileHandler(config.logs_dir / "cobalt_price.log")
        file_handler.setLevel(logging.INFO)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        
        return logger
    
    def _initialize_data_sources(self) -> List[DataSource]:
        """Initialize available data sources."""
        sources = []
        
        # Add Metal Price API source if API key is available
        if config.metal_price_api_key:
            sources.append(MetalPriceAPISource(config.metal_price_api_key))
            self.logger.info("Initialized Metal Price API data source")
        
        # Add web scraper source
        sources.append(WebScraperSource())
        self.logger.info("Initialized web scraper data source")
        
        # Add mock source for testing
        sources.append(MockSource())
        self.logger.info("Initialized mock data source")
        
        return sources
    
    def fetch_current_prices(self) -> List[PriceData]:
        """Fetch current cobalt prices from all available sources."""
        all_prices = []
        
        for source in self.data_sources:
            try:
                self.logger.info(f"Fetching prices from {source.name}")
                prices = source.get_current_price()
                if prices:
                    if isinstance(prices, list):
                        all_prices.extend(prices)
                    else:
                        all_prices.append(prices)
                    self.logger.info(f"Successfully fetched {len(prices) if isinstance(prices, list) else 1} prices from {source.name}")
                else:
                    self.logger.warning(f"No prices returned from {source.name}")
            except Exception as e:
                self.logger.error(f"Error fetching prices from {source.name}: {str(e)}")
        
        return all_prices
    
    def store_prices(self, prices: List[PriceData]) -> None:
        """Store price data in the database."""
        try:
            self.db_manager.save_prices(prices)
            self.logger.info(f"Stored {len(prices)} price records")
        except Exception as e:
            self.logger.error(f"Error storing prices: {str(e)}")
            raise
    
    def get_historical_prices(
        self, 
        days: int = 30, 
        source: Optional[str] = None
    ) -> List[CobaltPrice]:
        """Get historical price data."""
        start_date = datetime.now() - timedelta(days=days)
        return self.db_manager.get_prices_since(start_date, source)
    
    def get_latest_price(self, source: Optional[str] = None) -> Optional[CobaltPrice]:
        """Get the most recent price data."""
        return self.db_manager.get_latest_price(source)
    
    def get_price_statistics(self, days: int = 30) -> Dict[str, Any]:
        """Get price statistics for the specified period."""
        prices = self.get_historical_prices(days)
        
        if not prices:
            return {}
        
        price_values = [float(price.price) for price in prices]
        
        return {
            "count": len(price_values),
            "min": min(price_values),
            "max": max(price_values),
            "avg": sum(price_values) / len(price_values),
            "latest": float(prices[-1].price) if prices else None,
            "change_24h": self._calculate_change(prices, 1),
            "change_7d": self._calculate_change(prices, 7),
            "change_30d": self._calculate_change(prices, 30),
        }
    
    def _calculate_change(self, prices: List[CobaltPrice], days: int) -> Optional[float]:
        """Calculate price change over specified days."""
        if len(prices) < 2:
            return None
        
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_prices = [p for p in prices if p.timestamp >= cutoff_date]
        
        if len(recent_prices) < 2:
            return None
        
        old_price = float(recent_prices[0].price)
        new_price = float(recent_prices[-1].price)
        
        return ((new_price - old_price) / old_price) * 100
    
    def update_prices(self) -> Dict[str, Any]:
        """Fetch and store current prices from all sources."""
        start_time = datetime.now()
        
        try:
            prices = self.fetch_current_prices()
            if prices:
                self.store_prices(prices)
                
            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()
            
            result = {
                "success": True,
                "prices_fetched": len(prices),
                "duration_seconds": duration,
                "timestamp": start_time.isoformat(),
                "sources": list(set(price.source for price in prices))
            }
            
            self.logger.info(f"Price update completed: {result}")
            return result
            
        except Exception as e:
            self.logger.error(f"Price update failed: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "timestamp": start_time.isoformat()
            }
    
    def check_alerts(self) -> List[Dict[str, Any]]:
        """Check if any price alerts should be triggered."""
        alerts = self.db_manager.get_active_alerts()
        triggered_alerts = []
        
        latest_price = self.get_latest_price()
        if not latest_price:
            return triggered_alerts
        
        current_price = float(latest_price.price)
        
        for alert in alerts:
            should_trigger = False
            threshold = float(alert.threshold)
            
            if alert.alert_type == "above" and current_price > threshold:
                should_trigger = True
            elif alert.alert_type == "below" and current_price < threshold:
                should_trigger = True
            elif alert.alert_type == "change":
                # Check for significant price change
                historical_prices = self.get_historical_prices(1)  # Last 24 hours
                if len(historical_prices) >= 2:
                    old_price = float(historical_prices[0].price)
                    change_percent = abs((current_price - old_price) / old_price * 100)
                    if change_percent > threshold:
                        should_trigger = True
            
            if should_trigger:
                triggered_alerts.append({
                    "alert_id": alert.id,
                    "alert_type": alert.alert_type,
                    "threshold": threshold,
                    "current_price": current_price,
                    "email": alert.email
                })
                
                # Update last triggered timestamp
                self.db_manager.update_alert_triggered(alert.id)
        
        return triggered_alerts