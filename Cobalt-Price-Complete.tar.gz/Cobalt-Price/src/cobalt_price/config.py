"""Configuration management for the Cobalt Price Tracker."""

import os
from pathlib import Path
from typing import Optional
from pydantic import Field
from pydantic_settings import BaseSettings


class Config(BaseSettings):
    """Application configuration."""
    
    # API Keys
    metal_price_api_key: Optional[str] = Field(None, env="METAL_PRICE_API_KEY")
    alpha_vantage_api_key: Optional[str] = Field(None, env="ALPHA_VANTAGE_API_KEY")
    quandl_api_key: Optional[str] = Field(None, env="QUANDL_API_KEY")
    
    # Database
    database_url: str = Field("sqlite:///cobalt_prices.db", env="DATABASE_URL")
    
    # Update frequency in minutes
    update_interval: int = Field(60, env="UPDATE_INTERVAL")
    
    # Logging
    log_level: str = Field("INFO", env="LOG_LEVEL")
    log_file: str = Field("logs/cobalt_price.log", env="LOG_FILE")
    
    # Web interface
    web_host: str = Field("127.0.0.1", env="WEB_HOST")
    web_port: int = Field(8000, env="WEB_PORT")
    
    # Email notifications
    smtp_server: Optional[str] = Field(None, env="SMTP_SERVER")
    smtp_port: int = Field(587, env="SMTP_PORT")
    email_user: Optional[str] = Field(None, env="EMAIL_USER")
    email_password: Optional[str] = Field(None, env="EMAIL_PASSWORD")
    alert_email: Optional[str] = Field(None, env="ALERT_EMAIL")
    
    # Data directories
    data_dir: Path = Field(Path("data"), env="DATA_DIR")
    logs_dir: Path = Field(Path("logs"), env="LOGS_DIR")
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Ensure directories exist
        self.data_dir.mkdir(exist_ok=True)
        self.logs_dir.mkdir(exist_ok=True)


# Global config instance
config = Config()