"""
Cobalt Price Tracking System

A comprehensive tool for tracking, analyzing, and visualizing cobalt prices
from multiple data sources.
"""

__version__ = "0.1.0"
__author__ = "Luiz Persechini"
__email__ = "luizpersechini@example.com"

from .core import CobaltPriceTracker
from .config import Config

__all__ = ["CobaltPriceTracker", "Config"]