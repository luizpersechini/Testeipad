"""Report generation for cobalt price analysis."""

import json
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from pathlib import Path
import pandas as pd

from ..models import CobaltPrice
from ..config import config


class ReportGenerator:
    """Generates various reports for cobalt price analysis."""
    
    def __init__(self):
        self.output_dir = config.data_dir / "reports"
        self.output_dir.mkdir(exist_ok=True)
    
    def generate_summary_report(
        self, 
        prices: List[CobaltPrice], 
        period_days: int = 30
    ) -> Dict[str, Any]:
        """Generate a comprehensive summary report."""
        if not prices:
            return {"error": "No price data available"}
        
        df = self._prices_to_dataframe(prices)
        
        # Filter to specified period
        cutoff_date = datetime.now() - timedelta(days=period_days)
        period_df = df[df['timestamp'] >= cutoff_date]
        
        # Basic statistics
        stats = period_df['price'].describe()
        
        # Price changes
        price_changes = self._calculate_price_changes(period_df)
        
        # Source analysis
        source_stats = self._analyze_sources(period_df)
        
        # Trend analysis
        trend = self._analyze_trend(period_df)
        
        report = {
            "report_generated": datetime.now().isoformat(),
            "period_days": period_days,
            "data_points": len(period_df),
            "date_range": {
                "start": period_df['timestamp'].min().isoformat() if not period_df.empty else None,
                "end": period_df['timestamp'].max().isoformat() if not period_df.empty else None
            },
            "price_statistics": {
                "current": float(period_df['price'].iloc[-1]) if not period_df.empty else None,
                "average": float(stats['mean']),
                "median": float(stats['50%']),
                "min": float(stats['min']),
                "max": float(stats['max']),
                "std_dev": float(stats['std']),
                "volatility": float(stats['std'] / stats['mean'] * 100) if stats['mean'] > 0 else 0
            },
            "price_changes": price_changes,
            "source_analysis": source_stats,
            "trend_analysis": trend,
            "alerts": self._generate_alerts(period_df)
        }
        
        return report
    
    def save_report_json(
        self, 
        report: Dict[str, Any], 
        filename: Optional[str] = None
    ) -> Path:
        """Save report as JSON file."""
        if filename is None:
            filename = f"cobalt_price_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        file_path = self.output_dir / filename
        
        with open(file_path, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        return file_path
    
    def generate_html_report(
        self, 
        prices: List[CobaltPrice], 
        period_days: int = 30
    ) -> Path:
        """Generate an HTML report."""
        report_data = self.generate_summary_report(prices, period_days)
        
        html_content = self._create_html_report(report_data)
        
        filename = f"cobalt_price_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        file_path = self.output_dir / filename
        
        with open(file_path, 'w') as f:
            f.write(html_content)
        
        return file_path
    
    def generate_csv_export(
        self, 
        prices: List[CobaltPrice], 
        filename: Optional[str] = None
    ) -> Path:
        """Export price data to CSV."""
        if not prices:
            raise ValueError("No price data to export")
        
        df = self._prices_to_dataframe(prices)
        
        if filename is None:
            filename = f"cobalt_prices_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        file_path = self.output_dir / filename
        df.to_csv(file_path, index=False)
        
        return file_path
    
    def _prices_to_dataframe(self, prices: List[CobaltPrice]) -> pd.DataFrame:
        """Convert list of CobaltPrice objects to pandas DataFrame."""
        data = []
        for price in prices:
            data.append({
                'id': price.id,
                'timestamp': price.timestamp,
                'price': float(price.price),
                'currency': price.currency,
                'unit': price.unit,
                'source': price.source,
                'created_at': price.created_at
            })
        
        return pd.DataFrame(data).sort_values('timestamp')
    
    def _calculate_price_changes(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Calculate various price changes."""
        if df.empty or len(df) < 2:
            return {}
        
        current_price = df['price'].iloc[-1]
        
        changes = {}
        
        # Different time periods
        periods = [1, 7, 30]
        for days in periods:
            cutoff_date = datetime.now() - timedelta(days=days)
            period_data = df[df['timestamp'] >= cutoff_date]
            
            if not period_data.empty and len(period_data) > 1:
                old_price = period_data['price'].iloc[0]
                change_absolute = current_price - old_price
                change_percent = (change_absolute / old_price * 100) if old_price > 0 else 0
                
                changes[f"{days}d"] = {
                    "absolute": float(change_absolute),
                    "percent": float(change_percent),
                    "direction": "up" if change_absolute > 0 else "down" if change_absolute < 0 else "flat"
                }
        
        return changes
    
    def _analyze_sources(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Analyze data sources."""
        if df.empty:
            return {}
        
        source_stats = {}
        
        for source in df['source'].unique():
            source_data = df[df['source'] == source]
            stats = source_data['price'].describe()
            
            source_stats[source] = {
                "data_points": len(source_data),
                "average_price": float(stats['mean']),
                "price_range": {
                    "min": float(stats['min']),
                    "max": float(stats['max'])
                },
                "last_update": source_data['timestamp'].max().isoformat(),
                "reliability_score": min(100, len(source_data) / len(df) * 100)
            }
        
        return source_stats
    
    def _analyze_trend(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Analyze price trends."""
        if df.empty or len(df) < 3:
            return {"trend": "insufficient_data"}
        
        # Calculate moving averages
        df = df.copy()
        df['ma_short'] = df['price'].rolling(window=min(7, len(df))).mean()
        df['ma_long'] = df['price'].rolling(window=min(14, len(df))).mean()
        
        # Determine trend
        recent_short = df['ma_short'].iloc[-3:].mean()
        recent_long = df['ma_long'].iloc[-3:].mean()
        
        if recent_short > recent_long * 1.02:
            trend = "upward"
        elif recent_short < recent_long * 0.98:
            trend = "downward"
        else:
            trend = "sideways"
        
        # Calculate trend strength
        price_range = df['price'].max() - df['price'].min()
        recent_range = df['price'].iloc[-7:].max() - df['price'].iloc[-7:].min()
        trend_strength = (recent_range / price_range * 100) if price_range > 0 else 0
        
        return {
            "trend": trend,
            "strength": float(trend_strength),
            "moving_averages": {
                "short_term": float(recent_short) if not pd.isna(recent_short) else None,
                "long_term": float(recent_long) if not pd.isna(recent_long) else None
            }
        }
    
    def _generate_alerts(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """Generate alerts based on price analysis."""
        alerts = []
        
        if df.empty:
            return alerts
        
        # High volatility alert
        volatility = df['price'].std() / df['price'].mean() * 100
        if volatility > 10:  # More than 10% volatility
            alerts.append({
                "type": "high_volatility",
                "severity": "warning",
                "message": f"High price volatility detected: {volatility:.1f}%",
                "value": float(volatility)
            })
        
        # Significant price change alert
        if len(df) >= 2:
            recent_change = (df['price'].iloc[-1] - df['price'].iloc[-2]) / df['price'].iloc[-2] * 100
            if abs(recent_change) > 5:  # More than 5% change
                alerts.append({
                    "type": "significant_change",
                    "severity": "info",
                    "message": f"Significant price change: {recent_change:+.1f}%",
                    "value": float(recent_change)
                })
        
        # Data freshness alert
        latest_timestamp = df['timestamp'].max()
        hours_since_update = (datetime.now() - latest_timestamp).total_seconds() / 3600
        if hours_since_update > 24:
            alerts.append({
                "type": "stale_data",
                "severity": "warning",
                "message": f"Data is {hours_since_update:.1f} hours old",
                "value": float(hours_since_update)
            })
        
        return alerts
    
    def _create_html_report(self, report_data: Dict[str, Any]) -> str:
        """Create HTML report content."""
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Cobalt Price Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        .header {{ background-color: #2c3e50; color: white; padding: 20px; border-radius: 5px; }}
        .section {{ margin: 20px 0; padding: 15px; border-left: 4px solid #3498db; background-color: #f8f9fa; }}
        .metric {{ display: inline-block; margin: 10px; padding: 10px; background-color: white; border-radius: 5px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }}
        .alert {{ padding: 10px; margin: 5px 0; border-radius: 5px; }}
        .alert.warning {{ background-color: #fff3cd; border: 1px solid #ffeaa7; }}
        .alert.info {{ background-color: #d1ecf1; border: 1px solid #bee5eb; }}
        table {{ width: 100%; border-collapse: collapse; margin: 10px 0; }}
        th, td {{ padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background-color: #f2f2f2; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Cobalt Price Analysis Report</h1>
        <p>Generated: {report_data.get('report_generated', 'N/A')}</p>
        <p>Period: {report_data.get('period_days', 'N/A')} days | Data Points: {report_data.get('data_points', 'N/A')}</p>
    </div>
    
    <div class="section">
        <h2>Price Statistics</h2>
        <div class="metric">
            <h3>Current Price</h3>
            <h2>${report_data.get('price_statistics', {}).get('current', 'N/A')}</h2>
        </div>
        <div class="metric">
            <h3>Average Price</h3>
            <h2>${report_data.get('price_statistics', {}).get('average', 'N/A'):.2f}</h2>
        </div>
        <div class="metric">
            <h3>Price Range</h3>
            <p>${report_data.get('price_statistics', {}).get('min', 'N/A'):.2f} - ${report_data.get('price_statistics', {}).get('max', 'N/A'):.2f}</p>
        </div>
        <div class="metric">
            <h3>Volatility</h3>
            <p>{report_data.get('price_statistics', {}).get('volatility', 'N/A'):.1f}%</p>
        </div>
    </div>
    
    <div class="section">
        <h2>Price Changes</h2>
        <table>
            <tr><th>Period</th><th>Change ($)</th><th>Change (%)</th><th>Direction</th></tr>
        """
        
        for period, change in report_data.get('price_changes', {}).items():
            html += f"""
            <tr>
                <td>{period}</td>
                <td>${change['absolute']:+.2f}</td>
                <td>{change['percent']:+.1f}%</td>
                <td>{change['direction'].title()}</td>
            </tr>
            """
        
        html += """
        </table>
    </div>
    
    <div class="section">
        <h2>Data Sources</h2>
        <table>
            <tr><th>Source</th><th>Data Points</th><th>Avg Price</th><th>Reliability</th></tr>
        """
        
        for source, stats in report_data.get('source_analysis', {}).items():
            html += f"""
            <tr>
                <td>{source}</td>
                <td>{stats['data_points']}</td>
                <td>${stats['average_price']:.2f}</td>
                <td>{stats['reliability_score']:.0f}%</td>
            </tr>
            """
        
        html += """
        </table>
    </div>
    
    <div class="section">
        <h2>Trend Analysis</h2>
        """
        
        trend_data = report_data.get('trend_analysis', {})
        html += f"""
        <p><strong>Trend:</strong> {trend_data.get('trend', 'N/A').title()}</p>
        <p><strong>Strength:</strong> {trend_data.get('strength', 'N/A'):.1f}%</p>
        """
        
        html += """
    </div>
    
    <div class="section">
        <h2>Alerts</h2>
        """
        
        alerts = report_data.get('alerts', [])
        if alerts:
            for alert in alerts:
                html += f'<div class="alert {alert["severity"]}">{alert["message"]}</div>'
        else:
            html += '<p>No alerts at this time.</p>'
        
        html += """
    </div>
</body>
</html>
        """
        
        return html