"""Chart generation for cobalt price visualization."""

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import seaborn as sns
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from pathlib import Path

from ..models import CobaltPrice
from ..config import config


class ChartGenerator:
    """Generates various charts for cobalt price data."""
    
    def __init__(self):
        # Set up matplotlib and seaborn styling
        plt.style.use('seaborn-v0_8')
        sns.set_palette("husl")
        
        # Create output directory
        self.output_dir = config.data_dir / "charts"
        self.output_dir.mkdir(exist_ok=True)
    
    def create_price_timeline(
        self, 
        prices: List[CobaltPrice], 
        title: str = "Cobalt Price Timeline",
        save_path: Optional[Path] = None
    ) -> Path:
        """Create a timeline chart of cobalt prices."""
        if not prices:
            raise ValueError("No price data provided")
        
        # Convert to DataFrame for easier plotting
        df = self._prices_to_dataframe(prices)
        
        # Create the plot
        fig, ax = plt.subplots(figsize=(12, 6))
        
        # Group by source for different lines
        for source in df['source'].unique():
            source_data = df[df['source'] == source]
            ax.plot(source_data['timestamp'], source_data['price'], 
                   label=source, marker='o', markersize=3, linewidth=2)
        
        # Formatting
        ax.set_title(title, fontsize=16, fontweight='bold')
        ax.set_xlabel('Date', fontsize=12)
        ax.set_ylabel('Price (USD per lb)', fontsize=12)
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # Format x-axis dates
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        ax.xaxis.set_major_locator(mdates.DayLocator(interval=max(1, len(df) // 10)))
        plt.xticks(rotation=45)
        
        # Tight layout
        plt.tight_layout()
        
        # Save the plot
        if save_path is None:
            save_path = self.output_dir / f"price_timeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return save_path
    
    def create_price_comparison(
        self, 
        prices: List[CobaltPrice], 
        title: str = "Cobalt Price Comparison by Source",
        save_path: Optional[Path] = None
    ) -> Path:
        """Create a comparison chart showing prices from different sources."""
        if not prices:
            raise ValueError("No price data provided")
        
        df = self._prices_to_dataframe(prices)
        
        # Create subplots
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
        
        # Box plot by source
        sns.boxplot(data=df, x='source', y='price', ax=ax1)
        ax1.set_title('Price Distribution by Source', fontsize=14, fontweight='bold')
        ax1.set_ylabel('Price (USD per lb)')
        ax1.tick_params(axis='x', rotation=45)
        
        # Violin plot for distribution shape
        sns.violinplot(data=df, x='source', y='price', ax=ax2)
        ax2.set_title('Price Distribution Shape by Source', fontsize=14, fontweight='bold')
        ax2.set_ylabel('Price (USD per lb)')
        ax2.tick_params(axis='x', rotation=45)
        
        plt.suptitle(title, fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        # Save the plot
        if save_path is None:
            save_path = self.output_dir / f"price_comparison_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return save_path
    
    def create_price_statistics(
        self, 
        prices: List[CobaltPrice], 
        title: str = "Cobalt Price Statistics",
        save_path: Optional[Path] = None
    ) -> Path:
        """Create a comprehensive statistics chart."""
        if not prices:
            raise ValueError("No price data provided")
        
        df = self._prices_to_dataframe(prices)
        
        # Create subplots
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 10))
        
        # 1. Price histogram
        ax1.hist(df['price'], bins=20, alpha=0.7, color='skyblue', edgecolor='black')
        ax1.set_title('Price Distribution', fontweight='bold')
        ax1.set_xlabel('Price (USD per lb)')
        ax1.set_ylabel('Frequency')
        
        # 2. Daily price changes
        df_sorted = df.sort_values('timestamp')
        df_sorted['price_change'] = df_sorted['price'].pct_change() * 100
        ax2.plot(df_sorted['timestamp'], df_sorted['price_change'], 
                color='red', alpha=0.7, linewidth=1)
        ax2.set_title('Daily Price Changes (%)', fontweight='bold')
        ax2.set_xlabel('Date')
        ax2.set_ylabel('Change (%)')
        ax2.axhline(y=0, color='black', linestyle='--', alpha=0.5)
        
        # 3. Moving averages
        df_sorted['MA_7'] = df_sorted['price'].rolling(window=7, min_periods=1).mean()
        df_sorted['MA_30'] = df_sorted['price'].rolling(window=30, min_periods=1).mean()
        
        ax3.plot(df_sorted['timestamp'], df_sorted['price'], 
                label='Price', alpha=0.6, color='blue')
        ax3.plot(df_sorted['timestamp'], df_sorted['MA_7'], 
                label='7-day MA', color='orange', linewidth=2)
        ax3.plot(df_sorted['timestamp'], df_sorted['MA_30'], 
                label='30-day MA', color='red', linewidth=2)
        ax3.set_title('Price with Moving Averages', fontweight='bold')
        ax3.set_xlabel('Date')
        ax3.set_ylabel('Price (USD per lb)')
        ax3.legend()
        
        # 4. Source count
        source_counts = df['source'].value_counts()
        ax4.pie(source_counts.values, labels=source_counts.index, autopct='%1.1f%%')
        ax4.set_title('Data Points by Source', fontweight='bold')
        
        plt.suptitle(title, fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        # Save the plot
        if save_path is None:
            save_path = self.output_dir / f"price_statistics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return save_path
    
    def create_correlation_matrix(
        self, 
        prices: List[CobaltPrice], 
        title: str = "Price Correlation Between Sources",
        save_path: Optional[Path] = None
    ) -> Optional[Path]:
        """Create a correlation matrix for prices from different sources."""
        if not prices:
            raise ValueError("No price data provided")
        
        df = self._prices_to_dataframe(prices)
        
        # Pivot table to get sources as columns
        pivot_df = df.pivot_table(
            index='timestamp', 
            columns='source', 
            values='price', 
            aggfunc='mean'
        )
        
        # Need at least 2 sources for correlation
        if pivot_df.shape[1] < 2:
            return None
        
        # Calculate correlation matrix
        corr_matrix = pivot_df.corr()
        
        # Create the plot
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Create heatmap
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0,
                   square=True, ax=ax, cbar_kws={'shrink': 0.8})
        
        ax.set_title(title, fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        # Save the plot
        if save_path is None:
            save_path = self.output_dir / f"price_correlation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return save_path
    
    def _prices_to_dataframe(self, prices: List[CobaltPrice]) -> pd.DataFrame:
        """Convert list of CobaltPrice objects to pandas DataFrame."""
        data = []
        for price in prices:
            data.append({
                'timestamp': price.timestamp,
                'price': float(price.price),
                'currency': price.currency,
                'unit': price.unit,
                'source': price.source
            })
        
        return pd.DataFrame(data)
    
    def create_dashboard(
        self, 
        prices: List[CobaltPrice], 
        title: str = "Cobalt Price Dashboard",
        save_path: Optional[Path] = None
    ) -> Path:
        """Create a comprehensive dashboard with multiple visualizations."""
        if not prices:
            raise ValueError("No price data provided")
        
        df = self._prices_to_dataframe(prices)
        
        # Create a large figure with multiple subplots
        fig = plt.figure(figsize=(20, 12))
        
        # Define grid layout
        gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)
        
        # 1. Main price timeline (spans 2 columns)
        ax1 = fig.add_subplot(gs[0, :2])
        for source in df['source'].unique():
            source_data = df[df['source'] == source]
            ax1.plot(source_data['timestamp'], source_data['price'], 
                    label=source, marker='o', markersize=2, linewidth=1.5)
        ax1.set_title('Price Timeline', fontsize=14, fontweight='bold')
        ax1.set_ylabel('Price (USD per lb)')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. Current price gauge
        ax2 = fig.add_subplot(gs[0, 2])
        latest_price = df.iloc[-1]['price'] if not df.empty else 0
        ax2.text(0.5, 0.5, f'${latest_price:.2f}', 
                horizontalalignment='center', verticalalignment='center',
                fontsize=24, fontweight='bold', transform=ax2.transAxes)
        ax2.text(0.5, 0.2, 'Current Price\n(USD per lb)', 
                horizontalalignment='center', verticalalignment='center',
                fontsize=10, transform=ax2.transAxes)
        ax2.set_xlim(0, 1)
        ax2.set_ylim(0, 1)
        ax2.axis('off')
        
        # 3. Price distribution
        ax3 = fig.add_subplot(gs[1, 0])
        ax3.hist(df['price'], bins=15, alpha=0.7, color='lightblue', edgecolor='black')
        ax3.set_title('Price Distribution', fontweight='bold')
        ax3.set_xlabel('Price (USD per lb)')
        ax3.set_ylabel('Frequency')
        
        # 4. Source comparison
        ax4 = fig.add_subplot(gs[1, 1])
        source_stats = df.groupby('source')['price'].agg(['mean', 'std']).reset_index()
        ax4.bar(source_stats['source'], source_stats['mean'], 
               yerr=source_stats['std'], capsize=5, alpha=0.7)
        ax4.set_title('Average Price by Source', fontweight='bold')
        ax4.set_ylabel('Price (USD per lb)')
        ax4.tick_params(axis='x', rotation=45)
        
        # 5. Recent trend
        ax5 = fig.add_subplot(gs[1, 2])
        recent_data = df.tail(30)  # Last 30 data points
        ax5.plot(recent_data['timestamp'], recent_data['price'], 
                color='green', linewidth=2, marker='o', markersize=3)
        ax5.set_title('Recent Trend (Last 30 Points)', fontweight='bold')
        ax5.set_ylabel('Price (USD per lb)')
        ax5.tick_params(axis='x', rotation=45)
        
        # 6. Statistics table
        ax6 = fig.add_subplot(gs[2, :])
        stats = df['price'].describe()
        stats_data = [
            ['Count', f'{stats["count"]:.0f}'],
            ['Mean', f'${stats["mean"]:.2f}'],
            ['Std Dev', f'${stats["std"]:.2f}'],
            ['Min', f'${stats["min"]:.2f}'],
            ['25%', f'${stats["25%"]:.2f}'],
            ['Median', f'${stats["50%"]:.2f}'],
            ['75%', f'${stats["75%"]:.2f}'],
            ['Max', f'${stats["max"]:.2f}']
        ]
        
        table = ax6.table(cellText=stats_data, 
                         colLabels=['Statistic', 'Value'],
                         cellLoc='center', loc='center',
                         bbox=[0.0, 0.0, 1.0, 1.0])
        table.auto_set_font_size(False)
        table.set_fontsize(10)
        table.scale(1, 2)
        ax6.axis('off')
        ax6.set_title('Price Statistics', fontweight='bold', pad=20)
        
        plt.suptitle(title, fontsize=18, fontweight='bold')
        
        # Save the plot
        if save_path is None:
            save_path = self.output_dir / f"dashboard_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return save_path