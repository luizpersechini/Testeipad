"""Database management for cobalt price data."""

import json
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
from sqlalchemy import create_engine, desc, and_
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import SQLAlchemyError

from ..config import config
from ..models import Base, CobaltPrice, PriceAlert, PriceData


class DatabaseManager:
    """Manages database operations for cobalt price data."""
    
    def __init__(self, database_url: Optional[str] = None):
        self.database_url = database_url or config.database_url
        self.engine = create_engine(self.database_url, echo=False)
        self.SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=self.engine)
        
        # Create tables if they don't exist
        self.create_tables()
    
    def create_tables(self) -> None:
        """Create database tables if they don't exist."""
        try:
            Base.metadata.create_all(bind=self.engine)
        except SQLAlchemyError as e:
            raise Exception(f"Error creating database tables: {str(e)}")
    
    def get_session(self) -> Session:
        """Get a database session."""
        return self.SessionLocal()
    
    def save_prices(self, prices: List[PriceData]) -> None:
        """Save price data to the database."""
        session = self.get_session()
        try:
            for price_data in prices:
                # Convert PriceData to CobaltPrice model
                cobalt_price = CobaltPrice(
                    price=price_data.price,
                    currency=price_data.currency,
                    unit=price_data.unit,
                    source=price_data.source,
                    timestamp=price_data.timestamp,
                    extra_data=json.dumps(price_data.metadata) if price_data.metadata else None
                )
                session.add(cobalt_price)
            
            session.commit()
        except SQLAlchemyError as e:
            session.rollback()
            raise Exception(f"Error saving prices to database: {str(e)}")
        finally:
            session.close()
    
    def get_latest_price(self, source: Optional[str] = None) -> Optional[CobaltPrice]:
        """Get the most recent price record."""
        session = self.get_session()
        try:
            query = session.query(CobaltPrice)
            
            if source:
                query = query.filter(CobaltPrice.source == source)
            
            return query.order_by(desc(CobaltPrice.timestamp)).first()
        
        except SQLAlchemyError as e:
            raise Exception(f"Error retrieving latest price: {str(e)}")
        finally:
            session.close()
    
    def get_prices_since(self, since_date: datetime, source: Optional[str] = None) -> List[CobaltPrice]:
        """Get all price records since a specific date."""
        session = self.get_session()
        try:
            query = session.query(CobaltPrice).filter(CobaltPrice.timestamp >= since_date)
            
            if source:
                query = query.filter(CobaltPrice.source == source)
            
            return query.order_by(CobaltPrice.timestamp).all()
        
        except SQLAlchemyError as e:
            raise Exception(f"Error retrieving prices since {since_date}: {str(e)}")
        finally:
            session.close()
    
    def get_price_range(
        self, 
        start_date: datetime, 
        end_date: datetime, 
        source: Optional[str] = None
    ) -> List[CobaltPrice]:
        """Get price records within a date range."""
        session = self.get_session()
        try:
            query = session.query(CobaltPrice).filter(
                and_(
                    CobaltPrice.timestamp >= start_date,
                    CobaltPrice.timestamp <= end_date
                )
            )
            
            if source:
                query = query.filter(CobaltPrice.source == source)
            
            return query.order_by(CobaltPrice.timestamp).all()
        
        except SQLAlchemyError as e:
            raise Exception(f"Error retrieving prices in range {start_date} - {end_date}: {str(e)}")
        finally:
            session.close()
    
    def get_sources(self) -> List[str]:
        """Get all unique data sources."""
        session = self.get_session()
        try:
            sources = session.query(CobaltPrice.source).distinct().all()
            return [source[0] for source in sources]
        
        except SQLAlchemyError as e:
            raise Exception(f"Error retrieving sources: {str(e)}")
        finally:
            session.close()
    
    def get_price_count(self, source: Optional[str] = None) -> int:
        """Get the total number of price records."""
        session = self.get_session()
        try:
            query = session.query(CobaltPrice)
            
            if source:
                query = query.filter(CobaltPrice.source == source)
            
            return query.count()
        
        except SQLAlchemyError as e:
            raise Exception(f"Error counting prices: {str(e)}")
        finally:
            session.close()
    
    def delete_old_prices(self, days_to_keep: int = 365) -> int:
        """Delete price records older than specified days."""
        session = self.get_session()
        try:
            cutoff_date = datetime.now() - timedelta(days=days_to_keep)
            deleted_count = session.query(CobaltPrice).filter(
                CobaltPrice.timestamp < cutoff_date
            ).delete()
            
            session.commit()
            return deleted_count
        
        except SQLAlchemyError as e:
            session.rollback()
            raise Exception(f"Error deleting old prices: {str(e)}")
        finally:
            session.close()
    
    # Alert management methods
    
    def create_alert(
        self, 
        alert_type: str, 
        threshold: float, 
        currency: str = "USD",
        unit: str = "lb",
        email: Optional[str] = None
    ) -> PriceAlert:
        """Create a new price alert."""
        session = self.get_session()
        try:
            alert = PriceAlert(
                alert_type=alert_type,
                threshold=threshold,
                currency=currency,
                unit=unit,
                email=email
            )
            
            session.add(alert)
            session.commit()
            session.refresh(alert)
            return alert
        
        except SQLAlchemyError as e:
            session.rollback()
            raise Exception(f"Error creating alert: {str(e)}")
        finally:
            session.close()
    
    def get_active_alerts(self) -> List[PriceAlert]:
        """Get all active price alerts."""
        session = self.get_session()
        try:
            return session.query(PriceAlert).filter(PriceAlert.is_active == "true").all()
        
        except SQLAlchemyError as e:
            raise Exception(f"Error retrieving active alerts: {str(e)}")
        finally:
            session.close()
    
    def update_alert_triggered(self, alert_id: int) -> None:
        """Update the last triggered timestamp for an alert."""
        session = self.get_session()
        try:
            alert = session.query(PriceAlert).filter(PriceAlert.id == alert_id).first()
            if alert:
                alert.last_triggered = datetime.now()
                session.commit()
        
        except SQLAlchemyError as e:
            session.rollback()
            raise Exception(f"Error updating alert {alert_id}: {str(e)}")
        finally:
            session.close()
    
    def deactivate_alert(self, alert_id: int) -> bool:
        """Deactivate a price alert."""
        session = self.get_session()
        try:
            alert = session.query(PriceAlert).filter(PriceAlert.id == alert_id).first()
            if alert:
                alert.is_active = "false"
                session.commit()
                return True
            return False
        
        except SQLAlchemyError as e:
            session.rollback()
            raise Exception(f"Error deactivating alert {alert_id}: {str(e)}")
        finally:
            session.close()
    
    def get_database_stats(self) -> Dict[str, Any]:
        """Get database statistics."""
        session = self.get_session()
        try:
            total_prices = session.query(CobaltPrice).count()
            total_alerts = session.query(PriceAlert).count()
            active_alerts = session.query(PriceAlert).filter(PriceAlert.is_active == "true").count()
            
            # Get date range
            oldest_price = session.query(CobaltPrice).order_by(CobaltPrice.timestamp).first()
            newest_price = session.query(CobaltPrice).order_by(desc(CobaltPrice.timestamp)).first()
            
            # Get sources
            sources = self.get_sources()
            
            return {
                "total_prices": total_prices,
                "total_alerts": total_alerts,
                "active_alerts": active_alerts,
                "sources": sources,
                "oldest_record": oldest_price.timestamp.isoformat() if oldest_price else None,
                "newest_record": newest_price.timestamp.isoformat() if newest_price else None,
                "database_url": self.database_url
            }
        
        except SQLAlchemyError as e:
            raise Exception(f"Error retrieving database stats: {str(e)}")
        finally:
            session.close()