"""Storage modules for cobalt price data."""

from .database import DatabaseManager

__all__ = ["DatabaseManager"]